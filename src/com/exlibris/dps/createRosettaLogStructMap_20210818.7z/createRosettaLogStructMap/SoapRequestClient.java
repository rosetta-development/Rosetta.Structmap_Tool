package com.exlibris.dps.createRosettaLogStructMap;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class SoapRequestClient {

	static private int levelcounter = 0;
	private static ArrayList<String> fileidFilename = new ArrayList<String>();

	public static ArrayList<String> repLabels;
	static {
		repLabels = new ArrayList<>();
	}

//	public static HashMap<String, ArrayList<String>> FileId_FileIdNameLabel_Map;
//	static {
//		FileId_FileIdNameLabel_Map = new HashMap<>();
//	}
	public static HashMap<String, ArrayList<String>> FileName_FileIdNameLabel_Map;
	static {
		FileName_FileIdNameLabel_Map = new HashMap<>();
	}

	static String getIeXmlViaSoap(String wsurl, String user, String password, String institution, String iepid) throws MalformedURLException, IOException {
		//HTTP request
		String responseString = "";
		String outputString = "";
		URL url = new URL(wsurl);
		URLConnection connection = url.openConnection();
		HttpURLConnection httpConn = (HttpURLConnection)connection;

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		String xmlOutput = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
				"<Body><getIE xmlns=\"http://dps.exlibris.com/\"><pdsHandle xmlns=\"\"></pdsHandle><iePid xmlns=\"\">"+
				iepid+
				"</iePid></getIE><flags xmlns=\"\">16</flags></Body></Envelope>";
		/*
		 * flags -
0 - current IE version, including reps and files without derivative copy representations
1 - include all revisions and not just the latest (deprecated)
2 - exclude the files
4 - enrich with shared CMS metadata
8 - enrich with shared access rights metadata
16 - include minimal file information (file size, mimetype and FLocat)
32 - current IE version, including reps and files with derivative copy representations
		 */
		
		System.out.println("xmlOutput: "+xmlOutput);
		byte[] buffer = new byte[xmlOutput.length()];
		buffer = xmlOutput.getBytes();
		outputStream.write(buffer);
		byte[] b = outputStream.toByteArray();

		//set HTTP parameters
		/*	  SOAP action MUST NOT(!) be used:	    httpConn.setRequestProperty("SOAPAction", ...); */
		httpConn.setReadTimeout(120000); //set timeout to 2 minutes
		httpConn.setRequestProperty("Accept", "application/xml");
		httpConn.setRequestProperty("Authorization",
				"Basic " + Base64.getEncoder().encodeToString((user+"-institutionCode-"+institution+":"+password).getBytes()));

		httpConn.setRequestProperty("Content-Length",String.valueOf(b.length));
		httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true);
		httpConn.setDoInput(true);
		OutputStream out = httpConn.getOutputStream(); //write content of request to output stream of HTTP connection
		out.write(b);
		out.close(); //request sent

		//read response
		InputStreamReader isr = null;
		if (httpConn.getResponseCode() == 200) {
			isr = new InputStreamReader(httpConn.getInputStream());
		} else {
			isr = new InputStreamReader(httpConn.getErrorStream());
		}

		BufferedReader in = new BufferedReader(isr);

		//write response to a string
		while ((responseString = in.readLine()) != null) {
			outputString = outputString + responseString;
		}
		if (!outputString.isEmpty()) {
			try {
				outputString = extractIeXml(outputString, "getIE");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return outputString;
	}

//	/*
//	 * NOT in use: would be alternative for getIeXmlViaSoap if access rights exception is set for the SOAP user
//	 */
//	static String getIeXmlViaDelivery(String iepid) throws MalformedURLException, IOException {
//		//HTTP request
//		String responseString = "";
//		String outputString = "";
//		String deliveryurlstart = "http://maia.beic.it:1801/delivery/DeliveryManagerServlet?dps_pid=";
//		String deliveryurlend = "&change_lng=en&select_viewer=metsViewer&dps_func=mets";
//		String test_with_delivery = deliveryurlstart+iepid+deliveryurlend;
//		URL url = new URL(test_with_delivery);
//		URLConnection connection = url.openConnection();
//		HttpURLConnection httpConn = (HttpURLConnection)connection;
//
//		//read response
//		InputStreamReader isr = null;
//		if (httpConn.getResponseCode() == 200) {
//			isr = new InputStreamReader(httpConn.getInputStream());
//		} else {
//			isr = new InputStreamReader(httpConn.getErrorStream());
//		}
//
//		BufferedReader in = new BufferedReader(isr);
//
//		//write response to a string
//		while ((responseString = in.readLine()) != null) {
//			outputString = outputString + responseString;
//		}
//		return outputString;
//	}

	static String getSruResponse(String sruurl, String repid) throws MalformedURLException, IOException {

		//HTTP request
		String responseString = "";
		String outputString = "";
		URL url = new URL(sruurl + repid);
		URLConnection connection = url.openConnection();
		HttpURLConnection httpConn = (HttpURLConnection)connection;
		httpConn.setDoOutput(true);
		httpConn.setDoInput(true);
		OutputStream out = httpConn.getOutputStream(); //write content of request to output stream of HTTP connection
		out.close(); //request sent

		//read response
		InputStreamReader isr = null;
		if (httpConn.getResponseCode() == 200) {
			isr = new InputStreamReader(httpConn.getInputStream());
		} else {
			isr = new InputStreamReader(httpConn.getErrorStream());
		}

		BufferedReader in = new BufferedReader(isr);

		//write response to a string
		while ((responseString = in.readLine()) != null) {
			outputString = outputString + responseString;
		}
		return outputString;
	}


	/* 
	 * extract IE XML from SOAP response
	 */
	private static String extractIeXml(String xml, String element) throws Exception
	{
		//TEST TEST
		//TEST	xml = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><ns2:getIEResponse xmlns:ns2=\"http://dps.exlibris.com/\"><getIE>&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?&gt;  &lt;mets:mets xmlns:mets=\"http://www.loc.gov/METS/\"&gt;    &lt;mets:dmdSec ID=\"ie-dmd\"&gt;      &lt;mets:mdWrap MDTYPE=\"DC\"&gt;        &lt;mets:xmlData&gt;          &lt;dc:record xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"&gt;            &lt;dc:title&gt;Embedding Digital Preservation across the Organisation: A Case Study of Internal Collaboration in the National Library of New Zealand&lt;/dc:title&gt;            &lt;dc:creator&gt;Wu, C.&lt;/dc:creator&gt;            &lt;dc:date&gt;2012&lt;/dc:date&gt;          &lt;/dc:record&gt;        &lt;/mets:xmlData&gt;      &lt;/mets:mdWrap&gt;    &lt;/mets:dmdSec&gt;    &lt;mets:amdSec ID=\"REP53308-amd\"&gt;      &lt;mets:techMD ID=\"REP53308-amd-tech\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"&gt;              &lt;section id=\"generalRepCharacteristics\"&gt;                &lt;record&gt;                  &lt;key id=\"preservationType\"&gt;PRESERVATION_MASTER&lt;/key&gt;                  &lt;key id=\"usageType\"&gt;VIEW&lt;/key&gt;                  &lt;key id=\"RevisionNumber\"&gt;1&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"internalIdentifier\"&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;SIPID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;997&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;PID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;REP53308&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;DepositSetID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;10452&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"objectCharacteristics\"&gt;                &lt;record&gt;                  &lt;key id=\"objectType\"&gt;REPRESENTATION&lt;/key&gt;                  &lt;key id=\"creationDate\"&gt;2015-08-02 09:52:41&lt;/key&gt;                  &lt;key id=\"createdBy\"&gt;admin2&lt;/key&gt;                  &lt;key id=\"modificationDate\"&gt;2015-08-02 09:52:41&lt;/key&gt;                  &lt;key id=\"modifiedBy\"&gt;admin2&lt;/key&gt;                  &lt;key id=\"owner\"&gt;CRS00.INS00.DPR00&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;            &lt;/dnx&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:techMD&gt;      &lt;mets:rightsMD ID=\"REP53308-amd-rights\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"/&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:rightsMD&gt;      &lt;mets:digiprovMD ID=\"REP53308-amd-digiprov\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"/&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:digiprovMD&gt;    &lt;/mets:amdSec&gt;    &lt;mets:amdSec ID=\"FL53309-amd\"&gt;      &lt;mets:techMD ID=\"FL53309-amd-tech\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"&gt;              &lt;section id=\"objectCharacteristics\"&gt;                &lt;record&gt;                  &lt;key id=\"objectType\"&gt;FILE&lt;/key&gt;                  &lt;key id=\"creationDate\"&gt;2015-08-02 09:52:41&lt;/key&gt;                  &lt;key id=\"createdBy\"&gt;admin2&lt;/key&gt;                  &lt;key id=\"modificationDate\"&gt;2015-08-02 09:52:41&lt;/key&gt;                  &lt;key id=\"modifiedBy\"&gt;admin2&lt;/key&gt;                  &lt;key id=\"owner\"&gt;CRS00.INS00.DPR00&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"internalIdentifier\"&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;SIPID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;997&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;PID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;FL53309&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;DepositSetID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;10452&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"fileFixity\"&gt;                &lt;record&gt;                  &lt;key id=\"agent\"&gt;REG_SA_JAVA5_FIXITY&lt;/key&gt;                  &lt;key id=\"fixityType\"&gt;MD5&lt;/key&gt;                  &lt;key id=\"fixityValue\"&gt;dd71946697650bdcaef8b1b8e60179d0&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"agent\"&gt;REG_SA_JAVA5_FIXITY&lt;/key&gt;                  &lt;key id=\"fixityType\"&gt;SHA1&lt;/key&gt;                  &lt;key id=\"fixityValue\"&gt;b30bfd5f434bddbf275ddfaa0753dc23e692747a&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"agent\"&gt;REG_SA_JAVA5_FIXITY&lt;/key&gt;                  &lt;key id=\"fixityType\"&gt;CRC32&lt;/key&gt;                  &lt;key id=\"fixityValue\"&gt;ff96b3f7&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"vsOutcome\"&gt;                &lt;record&gt;                  &lt;key id=\"checkDate\"&gt;Sun Aug 02 09:53:03 CEST 2015&lt;/key&gt;                  &lt;key id=\"type\"&gt;CHECKSUM&lt;/key&gt;                  &lt;key id=\"vsAgent\"&gt;REG_SA_JAVA5_FIXITY&lt;/key&gt;                  &lt;key id=\"result\"&gt;PASSED&lt;/key&gt;                  &lt;key id=\"vsEvaluation\"&gt;PASSED&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"checkDate\"&gt;Sun Aug 02 09:53:03 CEST 2015&lt;/key&gt;                  &lt;key id=\"type\"&gt;VIRUSCHECK&lt;/key&gt;                  &lt;key id=\"vsAgent\"&gt;REG_SA_DPS&lt;/key&gt;                  &lt;key id=\"result\"&gt;PASSED&lt;/key&gt;                  &lt;key id=\"vsEvaluation\"&gt;PASSED&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"checkDate\"&gt;Sun Aug 02 09:53:03 CEST 2015&lt;/key&gt;                  &lt;key id=\"type\"&gt;FILE_FORMAT&lt;/key&gt;                  &lt;key id=\"vsAgent\"&gt;REG_SA_DROID , Version 6.01 , Signature version Binary SF v.81/ Container SF v.1&lt;/key&gt;                  &lt;key id=\"result\"&gt;PASSED&lt;/key&gt;                  &lt;key id=\"vsEvaluation\"&gt;PASSED&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"checkDate\"&gt;Sun Aug 02 09:53:03 CEST 2015&lt;/key&gt;                  &lt;key id=\"type\"&gt;TECHMD&lt;/key&gt;                  &lt;key id=\"vsAgent\"&gt;JHOVE , PDF-hul 1.7 , Plugin Version 3.0&lt;/key&gt;                  &lt;key id=\"result\"&gt;PASSED&lt;/key&gt;                  &lt;key id=\"vsEvaluation\"&gt;PASSED&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"checkDate\"&gt;Sun Aug 02 09:53:03 CEST 2015&lt;/key&gt;                  &lt;key id=\"type\"&gt;RISK_ANALYSIS&lt;/key&gt;                  &lt;key id=\"vsAgent\"&gt;REG_SA_DPS&lt;/key&gt;                  &lt;key id=\"result\"&gt;PASSED&lt;/key&gt;                  &lt;key id=\"vsEvaluation\"&gt;PASSED&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"fileVirusCheck\"&gt;                &lt;record&gt;                  &lt;key id=\"status\"&gt;PASSED&lt;/key&gt;                  &lt;key id=\"agent\"&gt;REG_SA_DPS&lt;/key&gt;                  &lt;key id=\"content\"&gt;/exlibris/dps/d4_1/profile/repository/storage1/2015/08/02/file_1/V1-FL53309.pdf is Virus Free&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"fileFormat\"&gt;                &lt;record&gt;                  &lt;key id=\"agent\"&gt;REG_SA_DROID&lt;/key&gt;                  &lt;key id=\"formatRegistry\"&gt;PRONOM&lt;/key&gt;                  &lt;key id=\"formatRegistryId\"&gt;fmt/18&lt;/key&gt;                  &lt;key id=\"formatName\"&gt;fmt/18&lt;/key&gt;                  &lt;key id=\"formatVersion\"&gt;1.4&lt;/key&gt;                  &lt;key id=\"formatDescription\"&gt;Portable Document Format&lt;/key&gt;                  &lt;key id=\"exactFormatIdentification\"&gt;true&lt;/key&gt;                  &lt;key id=\"mimeType\"&gt;application/pdf&lt;/key&gt;                  &lt;key id=\"agentVersion\"&gt;6.01&lt;/key&gt;                  &lt;key id=\"agentSignatureVersion\"&gt;Binary SF v.81/ Container SF v.1&lt;/key&gt;                  &lt;key id=\"formatLibraryVersion\"&gt;4.1081&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"generalFileCharacteristics\"&gt;                &lt;record&gt;                  &lt;key id=\"label\"&gt;Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf&lt;/key&gt;                  &lt;key id=\"fileLocationType\"&gt;FILE&lt;/key&gt;                  &lt;key id=\"fileOriginalName\"&gt;Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf&lt;/key&gt;                  &lt;key id=\"fileOriginalPath\"&gt;Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf&lt;/key&gt;                  &lt;key id=\"fileOriginalID\"&gt;/exlibris/dps/d4_1/profile/units/DTL01/deposit_area_1//10001-11000/dep_10452/deposit/content/streams/Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf&lt;/key&gt;                  &lt;key id=\"fileExtension\"&gt;pdf&lt;/key&gt;                  &lt;key id=\"fileMIMEType\"&gt;application/pdf&lt;/key&gt;                  &lt;key id=\"fileSizeBytes\"&gt;716523&lt;/key&gt;                  &lt;key id=\"formatLibraryId\"&gt;fmt/18&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"significantProperties\"&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.filterPipeline&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;FlateDecode&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.freeObjects&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;1&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.ID&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;[0xa35c24d4ff0cfab178d1adbc5b30a38729, 0xa35c24d4ff0cfab178d1adbc5b30a38729]&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.incrementalUpdates&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;0&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;object.author&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;wuc&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.creationDate&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;Thu Nov 14 09:58:42 CET 2013&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.originalFormatCreatingApplication&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;PScript5.dll Version 5.2.2&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.modifiedDate&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;Thu Nov 14 09:58:42 CET 2013&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;object.creatingApplication&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;GPL Ghostscript 8.15&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;object.title&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;Microsoft Word - Archiving2012_CynthiaWu_Internal_Collab_Paper.doc&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"significantPropertiesType\"&gt;pdf.objectsCount&lt;/key&gt;                  &lt;key id=\"significantPropertiesValue\"&gt;73&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"fileValidation\"&gt;                &lt;record&gt;                  &lt;key id=\"agent\"&gt;JHOVE , PDF-hul 1.7 , Plugin Version 3.0&lt;/key&gt;                  &lt;key id=\"pluginName\"&gt;PDF-hul-1.10&lt;/key&gt;                  &lt;key id=\"format\"&gt;PDF&lt;/key&gt;                  &lt;key id=\"version\"&gt;1.4&lt;/key&gt;                  &lt;key id=\"mimeType\"&gt;application/pdf&lt;/key&gt;                  &lt;key id=\"isValid\"&gt;true&lt;/key&gt;                  &lt;key id=\"isWellFormed\"&gt;true&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;            &lt;/dnx&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:techMD&gt;      &lt;mets:rightsMD ID=\"FL53309-amd-rights\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"/&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:rightsMD&gt;      &lt;mets:digiprovMD ID=\"FL53309-amd-digiprov\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"&gt;              &lt;section id=\"event\"&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2015-08-02 09:53:03&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;VALIDATION&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;27&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;PROCESS_ID=;TASK_ID=1;MF_ID=11222779;STATUS=SUCCESS;ALGORITHM_NAME=MD5;IE_PID=IE53307;FILE_NAME=Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf;COPY_ID=null;FILE_PID=FL53309;REP_PID=REP53308;SIP_ID=997;DATE=02 08 2015 09:53:03;DEPOSIT_ACTIVITY_ID=10452;PRODUCER_ID=163064;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;Fixity check performed on file&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierType1\"&gt;SOFTWARE&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierValue1\"&gt;REG_SA_JAVA5_FIXITY&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2015-08-02 09:53:03&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;VALIDATION&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;27&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;PROCESS_ID=;TASK_ID=1;MF_ID=11222779;STATUS=SUCCESS;ALGORITHM_NAME=SHA1;IE_PID=IE53307;FILE_NAME=Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf;COPY_ID=null;FILE_PID=FL53309;REP_PID=REP53308;SIP_ID=997;DATE=02 08 2015 09:53:03;DEPOSIT_ACTIVITY_ID=10452;PRODUCER_ID=163064;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;Fixity check performed on file&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierType1\"&gt;SOFTWARE&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierValue1\"&gt;REG_SA_JAVA5_FIXITY&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2015-08-02 09:53:03&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;VALIDATION&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;27&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;PROCESS_ID=;TASK_ID=1;MF_ID=11222779;STATUS=SUCCESS;ALGORITHM_NAME=CRC32;IE_PID=IE53307;FILE_NAME=Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf;COPY_ID=null;FILE_PID=FL53309;REP_PID=REP53308;SIP_ID=997;DATE=02 08 2015 09:53:03;DEPOSIT_ACTIVITY_ID=10452;PRODUCER_ID=163064;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;Fixity check performed on file&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierType1\"&gt;SOFTWARE&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierValue1\"&gt;REG_SA_JAVA5_FIXITY&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2015-08-02 09:53:03&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;VALIDATION&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;24&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;PROCESS_ID=;PID=FL53309;SIP_ID=997;DEPOSIT_ACTIVITY_ID=10452;MF_ID=11222779;TASK_ID=7;PRODUCER_ID=163064;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;Virus check performed on file&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierType1\"&gt;SOFTWARE&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierValue1\"&gt;REG_SA_DPS&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2015-08-02 09:53:03&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;VALIDATION&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;25&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;PROCESS_ID=;PID=FL53309;FILE_EXTENSION=pdf;SIP_ID=997;DEPOSIT_ACTIVITY_ID=10452;MF_ID=11222779;TASK_ID=48;IDENTIFICATION_METHOD=SIGNATURE;PRODUCER_ID=163064;FORMAT_ID=fmt/18;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;Format Identification performed on file&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierType1\"&gt;SOFTWARE&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierValue1\"&gt;REG_SA_DROID , Version 6.01 , Signature version Binary SF v.81/ Container SF v.1&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2015-08-02 09:53:03&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;VALIDATION&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;165&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;PROCESS_ID=;PID=FL53309;SIP_ID=997;DEPOSIT_ACTIVITY_ID=10452;MF_ID=11222779;TASK_ID=49;PRODUCER_ID=163064;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;Technical Metadata extraction performed on file&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierType1\"&gt;SOFTWARE&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierValue1\"&gt;JHOVE , PDF-hul 1.7 , Plugin Version 3.0&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;            &lt;/dnx&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:digiprovMD&gt;    &lt;/mets:amdSec&gt;    &lt;mets:amdSec ID=\"ie-amd\"&gt;      &lt;mets:techMD ID=\"ie-amd-tech\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"&gt;              &lt;section id=\"internalIdentifier\"&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;SIPID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;997&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;PID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;IE53307&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"internalIdentifierType\"&gt;DepositSetID&lt;/key&gt;                  &lt;key id=\"internalIdentifierValue\"&gt;10452&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"objectCharacteristics\"&gt;                &lt;record&gt;                  &lt;key id=\"objectType\"&gt;INTELLECTUAL_ENTITY&lt;/key&gt;                  &lt;key id=\"creationDate\"&gt;2015-08-02 09:52:41&lt;/key&gt;                  &lt;key id=\"createdBy\"&gt;admin2&lt;/key&gt;                  &lt;key id=\"modificationDate\"&gt;2016-01-10 10:00:20&lt;/key&gt;                  &lt;key id=\"modifiedBy\"&gt;admin1&lt;/key&gt;                  &lt;key id=\"owner\"&gt;CRS00.INS00.DPR00&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"generalIECharacteristics\"&gt;                &lt;record&gt;                  &lt;key id=\"status\"&gt;ACTIVE&lt;/key&gt;                  &lt;key id=\"IEEntityType\"&gt;Article&lt;/key&gt;                  &lt;key id=\"Version\"&gt;6&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"Collection\"&gt;                &lt;record&gt;                  &lt;key id=\"collectionId\"&gt;16010782&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;            &lt;/dnx&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:techMD&gt;      &lt;mets:rightsMD ID=\"ie-amd-rights\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"&gt;              &lt;section id=\"accessRightsPolicy\"&gt;                &lt;record&gt;                  &lt;key id=\"policyId\"&gt;AR_EVERYONE&lt;/key&gt;                  &lt;key id=\"policyDescription\"&gt;No restrictions&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;            &lt;/dnx&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:rightsMD&gt;      &lt;mets:digiprovMD ID=\"ie-amd-digiprov\"&gt;        &lt;mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\"&gt;          &lt;mets:xmlData&gt;            &lt;dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"&gt;              &lt;section id=\"producer\"&gt;                &lt;record&gt;                  &lt;key id=\"address1\"&gt;4 Michigan Av.&lt;/key&gt;                  &lt;key id=\"address3\"&gt;Chicago&lt;/key&gt;                  &lt;key id=\"address4\"&gt;UnitedStates&lt;/key&gt;                  &lt;key id=\"defaultLanguage\"&gt;en&lt;/key&gt;                  &lt;key id=\"emailAddress\"&gt;ido.peled@exlibrisgroup.com&lt;/key&gt;                  &lt;key id=\"firstName\"&gt;INS00&lt;/key&gt;                  &lt;key id=\"lastName\"&gt;DPR00&lt;/key&gt;                  &lt;key id=\"telephone1\"&gt;03-9668990&lt;/key&gt;                  &lt;key id=\"authorativeName\"&gt;Ex Libris Demo Producer&lt;/key&gt;                  &lt;key id=\"producerId\"&gt;163064&lt;/key&gt;                  &lt;key id=\"userIdAppId\"&gt;163060&lt;/key&gt;                  &lt;key id=\"zip\"&gt;85675&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"producerAgent\"&gt;                &lt;record&gt;                  &lt;key id=\"firstName\"&gt;Victoria&lt;/key&gt;                  &lt;key id=\"lastName\"&gt;Holmes&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;              &lt;section id=\"event\"&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2016-01-10 09:48:17&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;ENRICHMENT&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;401&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;COLLECTION_NAME=scholar;COLLECTION_ID=16010782;PID=IE53307;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;IE has been added to collection&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierType1\"&gt;USER&lt;/key&gt;                  &lt;key id=\"linkingAgentIdentifierValue1\"&gt;admin1&lt;/key&gt;                &lt;/record&gt;                &lt;record&gt;                  &lt;key id=\"eventDateTime\"&gt;2016-01-10 10:00:20&lt;/key&gt;                  &lt;key id=\"eventType\"&gt;PROCESSING&lt;/key&gt;                  &lt;key id=\"eventIdentifierType\"&gt;DPS&lt;/key&gt;                  &lt;key id=\"eventIdentifierValue\"&gt;414&lt;/key&gt;                  &lt;key id=\"eventOutcome1\"&gt;SUCCESS&lt;/key&gt;                  &lt;key id=\"eventOutcomeDetail1\"&gt;IE_PID=IE53307;TASK_ID=62;PROCESS_ID=16011350;&lt;/key&gt;                  &lt;key id=\"eventDescription\"&gt;Representation metadata has been updated&lt;/key&gt;                &lt;/record&gt;              &lt;/section&gt;            &lt;/dnx&gt;          &lt;/mets:xmlData&gt;        &lt;/mets:mdWrap&gt;      &lt;/mets:digiprovMD&gt;    &lt;/mets:amdSec&gt;    &lt;mets:fileSec&gt;      &lt;mets:fileGrp ID=\"REP53308\" ADMID=\"REP53308-amd\"&gt;        &lt;mets:file ID=\"FL53309\" ADMID=\"FL53309-amd\"&gt;          &lt;mets:FLocat LOCTYPE=\"URL\" xlin:href=\"/exlibris/dps/d4_1/profile/permanent/file/storage1/2015/08/02/file_1/V1-FL53309.pdf\" xmlns:xlin=\"http://www.w3.org/1999/xlink\"/&gt;        &lt;/mets:file&gt;      &lt;/mets:fileGrp&gt;    &lt;/mets:fileSec&gt;    &lt;mets:structMap ID=\"REP53308-1\" TYPE=\"PHYSICAL\"&gt;      &lt;mets:div LABEL=\"Preservation Master\"&gt;        &lt;mets:div LABEL=\"Table of Contents\"&gt;          &lt;mets:div LABEL=\"Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf\" TYPE=\"FILE\"&gt;            &lt;mets:fptr FILEID=\"FL53309\"/&gt;          &lt;/mets:div&gt;        &lt;/mets:div&gt;      &lt;/mets:div&gt;    &lt;/mets:structMap&gt;  &lt;/mets:mets&gt;</getIE></ns2:getIEResponse></soap:Body></soap:Envelope>";
//System.out.println("-----soap response: "+xml);
		String ieXml = new String();
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		docBuilderFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(new InputSource(new StringReader(xml))); 

		NodeList nl = doc.getElementsByTagName(element);

		if (nl != null) {
			ieXml = nl.item(0).getTextContent();
		}
		return ieXml;
	}

	/* 
	 * extract physical structure map from IE XML for given REP ID
	 * build array of filename and ID
	 */
	static ArrayList<String> getFileNameIdFromPhysicalStructMap(String ieXml, String repId) throws Exception
	{
		//TEST TEST
		// TEST ieXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>  <mets:mets xmlns:mets=\"http://www.loc.gov/METS/\">    <mets:dmdSec ID=\"ie-dmd\">      <mets:mdWrap MDTYPE=\"DC\">        <mets:xmlData>          <dc:record xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">            <dc:title>Embedding Digital Preservation across the Organisation: A Case Study of Internal Collaboration in the National Library of New Zealand</dc:title>            <dc:creator>Wu, C.</dc:creator>            <dc:date>2012</dc:date>          </dc:record>        </mets:xmlData>      </mets:mdWrap>    </mets:dmdSec>    <mets:amdSec ID=\"REP53308-amd\">      <mets:techMD ID=\"REP53308-amd-tech\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\">              <section id=\"generalRepCharacteristics\">                <record>                  <key id=\"preservationType\">PRESERVATION_MASTER</key>                  <key id=\"usageType\">VIEW</key>                  <key id=\"RevisionNumber\">1</key>                </record>              </section>              <section id=\"internalIdentifier\">                <record>                  <key id=\"internalIdentifierType\">SIPID</key>                  <key id=\"internalIdentifierValue\">997</key>                </record>                <record>                  <key id=\"internalIdentifierType\">PID</key>                  <key id=\"internalIdentifierValue\">REP53308</key>                </record>                <record>                  <key id=\"internalIdentifierType\">DepositSetID</key>                  <key id=\"internalIdentifierValue\">10452</key>                </record>              </section>              <section id=\"objectCharacteristics\">                <record>                  <key id=\"objectType\">REPRESENTATION</key>                  <key id=\"creationDate\">2015-08-02 09:52:41</key>                  <key id=\"createdBy\">admin2</key>                  <key id=\"modificationDate\">2015-08-02 09:52:41</key>                  <key id=\"modifiedBy\">admin2</key>                  <key id=\"owner\">CRS00.INS00.DPR00</key>                </record>              </section>            </dnx>          </mets:xmlData>        </mets:mdWrap>      </mets:techMD>      <mets:rightsMD ID=\"REP53308-amd-rights\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"/>          </mets:xmlData>        </mets:mdWrap>      </mets:rightsMD>      <mets:digiprovMD ID=\"REP53308-amd-digiprov\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"/>          </mets:xmlData>        </mets:mdWrap>      </mets:digiprovMD>    </mets:amdSec>    <mets:amdSec ID=\"FL53309-amd\">      <mets:techMD ID=\"FL53309-amd-tech\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\">              <section id=\"objectCharacteristics\">                <record>                  <key id=\"objectType\">FILE</key>                  <key id=\"creationDate\">2015-08-02 09:52:41</key>                  <key id=\"createdBy\">admin2</key>                  <key id=\"modificationDate\">2015-08-02 09:52:41</key>                  <key id=\"modifiedBy\">admin2</key>                  <key id=\"owner\">CRS00.INS00.DPR00</key>                </record>              </section>              <section id=\"internalIdentifier\">                <record>                  <key id=\"internalIdentifierType\">SIPID</key>                  <key id=\"internalIdentifierValue\">997</key>                </record>                <record>                  <key id=\"internalIdentifierType\">PID</key>                  <key id=\"internalIdentifierValue\">FL53309</key>                </record>                <record>                  <key id=\"internalIdentifierType\">DepositSetID</key>                  <key id=\"internalIdentifierValue\">10452</key>                </record>              </section>              <section id=\"fileFixity\">                <record>                  <key id=\"agent\">REG_SA_JAVA5_FIXITY</key>                  <key id=\"fixityType\">MD5</key>                  <key id=\"fixityValue\">dd71946697650bdcaef8b1b8e60179d0</key>                </record>                <record>                  <key id=\"agent\">REG_SA_JAVA5_FIXITY</key>                  <key id=\"fixityType\">SHA1</key>                  <key id=\"fixityValue\">b30bfd5f434bddbf275ddfaa0753dc23e692747a</key>                </record>                <record>                  <key id=\"agent\">REG_SA_JAVA5_FIXITY</key>                  <key id=\"fixityType\">CRC32</key>                  <key id=\"fixityValue\">ff96b3f7</key>                </record>              </section>              <section id=\"vsOutcome\">                <record>                  <key id=\"checkDate\">Sun Aug 02 09:53:03 CEST 2015</key>                  <key id=\"type\">CHECKSUM</key>                  <key id=\"vsAgent\">REG_SA_JAVA5_FIXITY</key>                  <key id=\"result\">PASSED</key>                  <key id=\"vsEvaluation\">PASSED</key>                </record>                <record>                  <key id=\"checkDate\">Sun Aug 02 09:53:03 CEST 2015</key>                  <key id=\"type\">VIRUSCHECK</key>                  <key id=\"vsAgent\">REG_SA_DPS</key>                  <key id=\"result\">PASSED</key>                  <key id=\"vsEvaluation\">PASSED</key>                </record>                <record>                  <key id=\"checkDate\">Sun Aug 02 09:53:03 CEST 2015</key>                  <key id=\"type\">FILE_FORMAT</key>                  <key id=\"vsAgent\">REG_SA_DROID , Version 6.01 , Signature version Binary SF v.81/ Container SF v.1</key>                  <key id=\"result\">PASSED</key>                  <key id=\"vsEvaluation\">PASSED</key>                </record>                <record>                  <key id=\"checkDate\">Sun Aug 02 09:53:03 CEST 2015</key>                  <key id=\"type\">TECHMD</key>                  <key id=\"vsAgent\">JHOVE , PDF-hul 1.7 , Plugin Version 3.0</key>                  <key id=\"result\">PASSED</key>                  <key id=\"vsEvaluation\">PASSED</key>                </record>                <record>                  <key id=\"checkDate\">Sun Aug 02 09:53:03 CEST 2015</key>                  <key id=\"type\">RISK_ANALYSIS</key>                  <key id=\"vsAgent\">REG_SA_DPS</key>                  <key id=\"result\">PASSED</key>                  <key id=\"vsEvaluation\">PASSED</key>                </record>              </section>              <section id=\"fileVirusCheck\">                <record>                  <key id=\"status\">PASSED</key>                  <key id=\"agent\">REG_SA_DPS</key>                  <key id=\"content\">/exlibris/dps/d4_1/profile/repository/storage1/2015/08/02/file_1/V1-FL53309.pdf is Virus Free</key>                </record>              </section>              <section id=\"fileFormat\">                <record>                  <key id=\"agent\">REG_SA_DROID</key>                  <key id=\"formatRegistry\">PRONOM</key>                  <key id=\"formatRegistryId\">fmt/18</key>                  <key id=\"formatName\">fmt/18</key>                  <key id=\"formatVersion\">1.4</key>                  <key id=\"formatDescription\">Portable Document Format</key>                  <key id=\"exactFormatIdentification\">true</key>                  <key id=\"mimeType\">application/pdf</key>                  <key id=\"agentVersion\">6.01</key>                  <key id=\"agentSignatureVersion\">Binary SF v.81/ Container SF v.1</key>                  <key id=\"formatLibraryVersion\">4.1081</key>                </record>              </section>              <section id=\"generalFileCharacteristics\">                <record>                  <key id=\"label\">Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf</key>                  <key id=\"fileLocationType\">FILE</key>                  <key id=\"fileOriginalName\">Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf</key>                  <key id=\"fileOriginalPath\">Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf</key>                  <key id=\"fileOriginalID\">/exlibris/dps/d4_1/profile/units/DTL01/deposit_area_1//10001-11000/dep_10452/deposit/content/streams/Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf</key>                  <key id=\"fileExtension\">pdf</key>                  <key id=\"fileMIMEType\">application/pdf</key>                  <key id=\"fileSizeBytes\">716523</key>                  <key id=\"formatLibraryId\">fmt/18</key>                </record>              </section>              <section id=\"significantProperties\">                <record>                  <key id=\"significantPropertiesType\">pdf.filterPipeline</key>                  <key id=\"significantPropertiesValue\">FlateDecode</key>                </record>                <record>                  <key id=\"significantPropertiesType\">pdf.freeObjects</key>                  <key id=\"significantPropertiesValue\">1</key>                </record>                <record>                  <key id=\"significantPropertiesType\">pdf.ID</key>                  <key id=\"significantPropertiesValue\">[0xa35c24d4ff0cfab178d1adbc5b30a38729, 0xa35c24d4ff0cfab178d1adbc5b30a38729]</key>                </record>                <record>                  <key id=\"significantPropertiesType\">pdf.incrementalUpdates</key>                  <key id=\"significantPropertiesValue\">0</key>                </record>                <record>                  <key id=\"significantPropertiesType\">object.author</key>                  <key id=\"significantPropertiesValue\">wuc</key>                </record>                <record>                  <key id=\"significantPropertiesType\">pdf.creationDate</key>                  <key id=\"significantPropertiesValue\">Thu Nov 14 09:58:42 CET 2013</key>                </record>                <record>                  <key id=\"significantPropertiesType\">pdf.originalFormatCreatingApplication</key>                  <key id=\"significantPropertiesValue\">PScript5.dll Version 5.2.2</key>                </record>                <record>                  <key id=\"significantPropertiesType\">pdf.modifiedDate</key>                  <key id=\"significantPropertiesValue\">Thu Nov 14 09:58:42 CET 2013</key>                </record>                <record>                  <key id=\"significantPropertiesType\">object.creatingApplication</key>                  <key id=\"significantPropertiesValue\">GPL Ghostscript 8.15</key>                </record>                <record>                  <key id=\"significantPropertiesType\">object.title</key>                  <key id=\"significantPropertiesValue\">Microsoft Word - Archiving2012_CynthiaWu_Internal_Collab_Paper.doc</key>                </record>                <record>                  <key id=\"significantPropertiesType\">pdf.objectsCount</key>                  <key id=\"significantPropertiesValue\">73</key>                </record>              </section>              <section id=\"fileValidation\">                <record>                  <key id=\"agent\">JHOVE , PDF-hul 1.7 , Plugin Version 3.0</key>                  <key id=\"pluginName\">PDF-hul-1.10</key>                  <key id=\"format\">PDF</key>                  <key id=\"version\">1.4</key>                  <key id=\"mimeType\">application/pdf</key>                  <key id=\"isValid\">true</key>                  <key id=\"isWellFormed\">true</key>                </record>              </section>            </dnx>          </mets:xmlData>        </mets:mdWrap>      </mets:techMD>      <mets:rightsMD ID=\"FL53309-amd-rights\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\"/>          </mets:xmlData>        </mets:mdWrap>      </mets:rightsMD>      <mets:digiprovMD ID=\"FL53309-amd-digiprov\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\">              <section id=\"event\">                <record>                  <key id=\"eventDateTime\">2015-08-02 09:53:03</key>                  <key id=\"eventType\">VALIDATION</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">27</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">PROCESS_ID=;TASK_ID=1;MF_ID=11222779;STATUS=SUCCESS;ALGORITHM_NAME=MD5;IE_PID=IE53307;FILE_NAME=Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf;COPY_ID=null;FILE_PID=FL53309;REP_PID=REP53308;SIP_ID=997;DATE=02 08 2015 09:53:03;DEPOSIT_ACTIVITY_ID=10452;PRODUCER_ID=163064;</key>                  <key id=\"eventDescription\">Fixity check performed on file</key>                  <key id=\"linkingAgentIdentifierType1\">SOFTWARE</key>                  <key id=\"linkingAgentIdentifierValue1\">REG_SA_JAVA5_FIXITY</key>                </record>                <record>                  <key id=\"eventDateTime\">2015-08-02 09:53:03</key>                  <key id=\"eventType\">VALIDATION</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">27</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">PROCESS_ID=;TASK_ID=1;MF_ID=11222779;STATUS=SUCCESS;ALGORITHM_NAME=SHA1;IE_PID=IE53307;FILE_NAME=Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf;COPY_ID=null;FILE_PID=FL53309;REP_PID=REP53308;SIP_ID=997;DATE=02 08 2015 09:53:03;DEPOSIT_ACTIVITY_ID=10452;PRODUCER_ID=163064;</key>                  <key id=\"eventDescription\">Fixity check performed on file</key>                  <key id=\"linkingAgentIdentifierType1\">SOFTWARE</key>                  <key id=\"linkingAgentIdentifierValue1\">REG_SA_JAVA5_FIXITY</key>                </record>                <record>                  <key id=\"eventDateTime\">2015-08-02 09:53:03</key>                  <key id=\"eventType\">VALIDATION</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">27</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">PROCESS_ID=;TASK_ID=1;MF_ID=11222779;STATUS=SUCCESS;ALGORITHM_NAME=CRC32;IE_PID=IE53307;FILE_NAME=Archiving2012-CynthiaWu-Internal-Collab-Paper.pdf;COPY_ID=null;FILE_PID=FL53309;REP_PID=REP53308;SIP_ID=997;DATE=02 08 2015 09:53:03;DEPOSIT_ACTIVITY_ID=10452;PRODUCER_ID=163064;</key>                  <key id=\"eventDescription\">Fixity check performed on file</key>                  <key id=\"linkingAgentIdentifierType1\">SOFTWARE</key>                  <key id=\"linkingAgentIdentifierValue1\">REG_SA_JAVA5_FIXITY</key>                </record>                <record>                  <key id=\"eventDateTime\">2015-08-02 09:53:03</key>                  <key id=\"eventType\">VALIDATION</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">24</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">PROCESS_ID=;PID=FL53309;SIP_ID=997;DEPOSIT_ACTIVITY_ID=10452;MF_ID=11222779;TASK_ID=7;PRODUCER_ID=163064;</key>                  <key id=\"eventDescription\">Virus check performed on file</key>                  <key id=\"linkingAgentIdentifierType1\">SOFTWARE</key>                  <key id=\"linkingAgentIdentifierValue1\">REG_SA_DPS</key>                </record>                <record>                  <key id=\"eventDateTime\">2015-08-02 09:53:03</key>                  <key id=\"eventType\">VALIDATION</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">25</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">PROCESS_ID=;PID=FL53309;FILE_EXTENSION=pdf;SIP_ID=997;DEPOSIT_ACTIVITY_ID=10452;MF_ID=11222779;TASK_ID=48;IDENTIFICATION_METHOD=SIGNATURE;PRODUCER_ID=163064;FORMAT_ID=fmt/18;</key>                  <key id=\"eventDescription\">Format Identification performed on file</key>                  <key id=\"linkingAgentIdentifierType1\">SOFTWARE</key>                  <key id=\"linkingAgentIdentifierValue1\">REG_SA_DROID , Version 6.01 , Signature version Binary SF v.81/ Container SF v.1</key>                </record>                <record>                  <key id=\"eventDateTime\">2015-08-02 09:53:03</key>                  <key id=\"eventType\">VALIDATION</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">165</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">PROCESS_ID=;PID=FL53309;SIP_ID=997;DEPOSIT_ACTIVITY_ID=10452;MF_ID=11222779;TASK_ID=49;PRODUCER_ID=163064;</key>                  <key id=\"eventDescription\">Technical Metadata extraction performed on file</key>                  <key id=\"linkingAgentIdentifierType1\">SOFTWARE</key>                  <key id=\"linkingAgentIdentifierValue1\">JHOVE , PDF-hul 1.7 , Plugin Version 3.0</key>                </record>              </section>            </dnx>          </mets:xmlData>        </mets:mdWrap>      </mets:digiprovMD>    </mets:amdSec>    <mets:amdSec ID=\"ie-amd\">      <mets:techMD ID=\"ie-amd-tech\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\">              <section id=\"internalIdentifier\">                <record>                  <key id=\"internalIdentifierType\">SIPID</key>                  <key id=\"internalIdentifierValue\">997</key>                </record>                <record>                  <key id=\"internalIdentifierType\">PID</key>                  <key id=\"internalIdentifierValue\">IE53307</key>                </record>                <record>                  <key id=\"internalIdentifierType\">DepositSetID</key>                  <key id=\"internalIdentifierValue\">10452</key>                </record>              </section>              <section id=\"objectCharacteristics\">                <record>                  <key id=\"objectType\">INTELLECTUAL_ENTITY</key>                  <key id=\"creationDate\">2015-08-02 09:52:41</key>                  <key id=\"createdBy\">admin2</key>                  <key id=\"modificationDate\">2016-01-10 10:00:20</key>                  <key id=\"modifiedBy\">admin1</key>                  <key id=\"owner\">CRS00.INS00.DPR00</key>                </record>              </section>              <section id=\"generalIECharacteristics\">                <record>                  <key id=\"status\">ACTIVE</key>                  <key id=\"IEEntityType\">Article</key>                  <key id=\"Version\">6</key>                </record>              </section>              <section id=\"Collection\">                <record>                  <key id=\"collectionId\">16010782</key>                </record>              </section>            </dnx>          </mets:xmlData>        </mets:mdWrap>      </mets:techMD>      <mets:rightsMD ID=\"ie-amd-rights\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\">              <section id=\"accessRightsPolicy\">                <record>                  <key id=\"policyId\">AR_EVERYONE</key>                  <key id=\"policyDescription\">No restrictions</key>                </record>              </section>            </dnx>          </mets:xmlData>        </mets:mdWrap>      </mets:rightsMD>      <mets:digiprovMD ID=\"ie-amd-digiprov\">        <mets:mdWrap MDTYPE=\"OTHER\" OTHERMDTYPE=\"dnx\">          <mets:xmlData>            <dnx xmlns=\"http://www.exlibrisgroup.com/dps/dnx\">              <section id=\"producer\">                <record>                  <key id=\"address1\">4 Michigan Av.</key>                  <key id=\"address3\">Chicago</key>                  <key id=\"address4\">UnitedStates</key>                  <key id=\"defaultLanguage\">en</key>                  <key id=\"emailAddress\">ido.peled@exlibrisgroup.com</key>                  <key id=\"firstName\">INS00</key>                  <key id=\"lastName\">DPR00</key>                  <key id=\"telephone1\">03-9668990</key>                  <key id=\"authorativeName\">Ex Libris Demo Producer</key>                  <key id=\"producerId\">163064</key>                  <key id=\"userIdAppId\">163060</key>                  <key id=\"zip\">85675</key>                </record>              </section>              <section id=\"producerAgent\">                <record>                  <key id=\"firstName\">Victoria</key>                  <key id=\"lastName\">Holmes</key>                </record>              </section>              <section id=\"event\">                <record>                  <key id=\"eventDateTime\">2016-01-10 09:48:17</key>                  <key id=\"eventType\">ENRICHMENT</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">401</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">COLLECTION_NAME=scholar;COLLECTION_ID=16010782;PID=IE53307;</key>                  <key id=\"eventDescription\">IE has been added to collection</key>                  <key id=\"linkingAgentIdentifierType1\">USER</key>                  <key id=\"linkingAgentIdentifierValue1\">admin1</key>                </record>                <record>                  <key id=\"eventDateTime\">2016-01-10 10:00:20</key>                  <key id=\"eventType\">PROCESSING</key>                  <key id=\"eventIdentifierType\">DPS</key>                  <key id=\"eventIdentifierValue\">414</key>                  <key id=\"eventOutcome1\">SUCCESS</key>                  <key id=\"eventOutcomeDetail1\">IE_PID=IE53307;TASK_ID=62;PROCESS_ID=16011350;</key>                  <key id=\"eventDescription\">Representation metadata has been updated</key>                </record>              </section>            </dnx>          </mets:xmlData>        </mets:mdWrap>      </mets:digiprovMD>    </mets:amdSec>    <mets:fileSec>      <mets:fileGrp ID=\"REP53308\" ADMID=\"REP53308-amd\">        <mets:file ID=\"FL53309\" ADMID=\"FL53309-amd\">          <mets:FLocat LOCTYPE=\"URL\" xlin:href=\"/exlibris/dps/d4_1/profile/permanent/file/storage1/2015/08/02/file_1/V1-FL53309.pdf\" xmlns:xlin=\"http://www.w3.org/1999/xlink\"/>        </mets:file>      </mets:fileGrp>    </mets:fileSec>    <mets:structMap ID=\"REP53308-1\" TYPE=\"PHYSICAL\">      <mets:div LABEL=\"Preservation Master\">        <mets:div LABEL=\"Table of Contents\">          <mets:div LABEL=\"111.pdf\" TYPE=\"FILE\">            <mets:fptr FILEID=\"FL0001\"/>          </mets:div>  <mets:div LABEL=\"222.pdf\" TYPE=\"FILE\">            <mets:fptr FILEID=\"FL0002\"/>          </mets:div>   <mets:div LABEL=\"333.pdf\" TYPE=\"FILE\">            <mets:fptr FILEID=\"FL0003\"/>          </mets:div>   </mets:div>      </mets:div>    </mets:structMap>  </mets:mets>";

		//clear for batch processing
		FileName_FileIdNameLabel_Map.clear(); 
		fileidFilename.clear();
		repLabels.clear();
		
		DocumentBuilderFactory docBuilderFactory1 = DocumentBuilderFactory.newInstance();
		docBuilderFactory1.setNamespaceAware(true);
		DocumentBuilder docBuilder1 = docBuilderFactory1.newDocumentBuilder();
		Document doc1 = docBuilder1.parse(new InputSource(new StringReader(ieXml))); 

		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		XPathExpression expr = xpath.compile("//*[local-name()='mets']/*[local-name()='structMap'][@TYPE=\"PHYSICAL\"]");
		NodeList nl = (NodeList) expr.evaluate(doc1, XPathConstants.NODESET); //nodes of physical structure map
		Node root = nl.item(0);
		ArrayList<String> alFilenameId = new ArrayList<String>();
		alFilenameId.clear();
		//check if rep id of structure map is the requested representation
		if (root.getAttributes().getNamedItem("ID").getNodeValue().equalsIgnoreCase(repId+"-1")) {
			printTags(root, true);
			for (Entry<String, ArrayList<String>> entry : FileName_FileIdNameLabel_Map.entrySet()) {
				alFilenameId = entry.getValue();
			}
		}
		return alFilenameId;   
	}


	public static void printTags(Node nodes, boolean from_physical){
		String fileid = null;
		String filename = null;
		Node nlabel;
		Node nfileid;
		Node ntype;
		if(nodes.hasChildNodes()  || nodes.getNodeType()!=3){
			nlabel = nodes.getAttributes().getNamedItem("LABEL");
			nfileid = nodes.getAttributes().getNamedItem("FILEID");
			ntype = nodes.getAttributes().getNamedItem("TYPE");
			if (nlabel!=null && ntype==null) {
				String repLabel = nodes.getAttributes().getNamedItem("LABEL").getNodeValue();
				repLabels.add(repLabel);
			}
			if (from_physical && nlabel!=null && ntype!=null) {
				filename = nodes.getAttributes().getNamedItem("LABEL").getNodeValue();
				fileidFilename.add(filename);
				FileName_FileIdNameLabel_Map.put(filename, fileidFilename);
			}
			if (nfileid!=null) {
				fileid = nodes.getAttributes().getNamedItem("FILEID").getNodeValue();
				fileidFilename.add(fileid);
			}
			
			NodeList nl=nodes.getChildNodes();
			for(int j=0;j<nl.getLength();j++) {
                printTags(nl.item(j), true);
			}
		}
	}

	static String addMdViaSoap(String wsurl, String user, String password, String institution, 
			String objectid, String contentxml, String commit, String type, String subType)
					throws MalformedURLException, IOException, Exception {
		//HTTP request
		String responseString = new String();
		String outputString = new String();
		URL url = new URL(wsurl);
		URLConnection connection = url.openConnection();
		HttpURLConnection httpConn = (HttpURLConnection)connection;

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		String envelope = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+"<Body>"
				+ "<updateMD xmlns=\"http://dps.exlibris.com/\">"
				+  "<commit xmlns=\"\">" + commit + "</commit>" //should better be 'true' because otherwise IEs will be locked until confirmation
				+  "<metadata xmlns=\"\">"
				+   "<content><![CDATA[" + contentxml + "]]></content>" //actual MD XML must be in CDATA
				/*+   "<mid></mid>" */
				/* <mid> MUST NOT exist (must be null), otherwise error in server.log: "updateMD has thrown exception, unwinding now: 
				com.exlibris.core.sdk.exceptions.InvalidMIDException: Cannot Update IE, PID:REP53308 and MetaData, MID: since There isnt any MetaData with specified MID and Type" */
				+   "<type>" + type + "</type>"
				+   "<subType>" + subType + "</subType>"
				+  "</metadata>"
				+  "<PID xmlns=\"\">"+ objectid +"</PID>"
				+  "<pdsHandle xmlns=\"\"></pdsHandle>" // is empty because of '_Basic_ authentication'
				+ "</updateMD>"
				+"</Body></Envelope>";

		byte[] buffer = new byte[envelope.length()];
		buffer = envelope.getBytes();
		outputStream.write(buffer);
		byte[] bout = outputStream.toByteArray();

		//set HTTP parameters
		/*	  SOAP action MUST NOT(!) be used:	    httpConn.setRequestProperty("SOAPAction", ...); */
		httpConn.setRequestProperty("Accept", "application/xml");
		httpConn.setRequestProperty("Authorization",
				"Basic " + Base64.getEncoder().encodeToString((user+"-institutionCode-"+institution+":"+password).getBytes()));
		httpConn.setRequestProperty("Content-Length",String.valueOf(bout.length));
		httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true);
		httpConn.setDoInput(true);
		OutputStream out = httpConn.getOutputStream(); //write content of request to output stream of HTTP connection
		out.write(bout);
		out.close(); //request has been sent

		//read response
		InputStreamReader isr = null;
		if (httpConn.getResponseCode() == 200) {
			isr = new InputStreamReader(httpConn.getInputStream());
		} else {
			isr = new InputStreamReader(httpConn.getErrorStream());
		}

		BufferedReader in = new BufferedReader(isr);

		//write response to a string
		while ((responseString = in.readLine()) != null) {
			outputString = outputString + responseString;
		}
		return outputString;
	}


	static String getLogicalStructmapViaSoap(String wsurl, String user, String password, String institution, String repmid) throws MalformedURLException, IOException {
		//HTTP request
		String responseString = "";
		String outputString = "";
		String type = "mets_section";
		String subType = "structMap";
		URL url = new URL(wsurl);
		URLConnection connection = url.openConnection();
		HttpURLConnection httpConn = (HttpURLConnection)connection;

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		String xmlOutput = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		        +"<Body>"
				+ "<getMD xmlns=\"http://dps.exlibris.com/\">"
				+   "<mid xmlns=\"\">" + repmid + "</mid>"
				+   "<PID xmlns=\"\">" + repmid.substring(0, repmid.indexOf("-")) + "</PID>"
				+   "<pdsHandle xmlns=\"\"></pdsHandle>"
				+   "<type xmlns=\"\">" + type + "</type>"
				+   "<subType xmlns=\"\">" + subType + "</subType>"
				+ "</getMD>"
				+"</Body></Envelope>";
		
		System.out.println("getLogicalStructmapViaSoap - xmlOutput: "+xmlOutput);
		byte[] buffer = new byte[xmlOutput.length()];
		buffer = xmlOutput.getBytes();
		outputStream.write(buffer);
		byte[] b = outputStream.toByteArray();

		//set HTTP parameters
		/*	  SOAP action MUST NOT(!) be used:	    httpConn.setRequestProperty("SOAPAction", ...); */
		httpConn.setReadTimeout(120000); //set timeout to 2 minutes
		httpConn.setRequestProperty("Accept", "application/xml");
		httpConn.setRequestProperty("Authorization",
				"Basic " + Base64.getEncoder().encodeToString((user+"-institutionCode-"+institution+":"+password).getBytes()));

		httpConn.setRequestProperty("Content-Length",String.valueOf(b.length));
		httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true);
		httpConn.setDoInput(true);
		OutputStream out = httpConn.getOutputStream(); //write content of request to output stream of HTTP connection
		out.write(b);
		out.close(); //request sent

		//read response
		InputStreamReader isr = null;
		if (httpConn.getResponseCode() == 200) {
			isr = new InputStreamReader(httpConn.getInputStream());
		} else {
			isr = new InputStreamReader(httpConn.getErrorStream());
		}

		BufferedReader in = new BufferedReader(isr);

		//write response to a string
		while ((responseString = in.readLine()) != null) {
			outputString = outputString + responseString;
		}
		if (!outputString.isEmpty()) {
			try {
				outputString = extractIeXml(outputString, "getMD");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return outputString;
	}


	  public static void main(String args[]) {

		//		// TEST TEST TEST
		//		//		String sruurl = "https://rosetta.exlibrisgroup.com/delivery/sru?"+
		//		//				"operation=searchRetrieve&startRecord=1&"+
		//		//				"query=REP.internalIdentifier.internalIdentifierType.PID=";
		//		//		String repid = "REP53308";
		//		//		try {
		//		//			//TEST			String sruresponse = "<searchRetrieveResponse xmlns=\"http://www.loc.gov/zing/srw/\"><version>1.2</version><numberOfRecords>1</numberOfRecords><records><record><recordSchema>info:srw/schema/1/dc-v1.1</recordSchema><recordPacking>xml</recordPacking><recordData><dc:record xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:dcterms=\"http://purl.org/dc/terms/\"><dc:creator xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">test_2.1</dc:creator><dc:title xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">test_2.1</dc:title><dc:description xml:lang=\"English\" xsi:type=\"pages\" xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">test_2.1</dc:description><dc:type xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">Manuscripts</dc:type><dcterms:created xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">14/09/2010</dcterms:created><dc:publisher xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\"/><dc:description xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\"/><dc:creator xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">Nir Sherwinter</dc:creator><dc:identifier xsi:type=\"PID\">IE1000</dc:identifier><dc:rights>6683</dc:rights><dc:identifier xsi:type=\"entityType\">Picture</dc:identifier><dc:identifier xsi:type=\"stream\">https://rosetta.exlibrisgroup.com:443/delivery/DeliveryManagerServlet?dps_pid=IE1000</dc:identifier><dc:identifier xsi:type=\"thumbnail\">https://rosetta.exlibrisgroup.com:443/delivery/DeliveryManagerServlet?dps_pid=IE1000&amp;dps_func=thumbnail</dc:identifier></dc:record></recordData><recordPosition>1</recordPosition></record></records></searchRetrieveResponse>";
		//		//			//TEST			String test = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><bbb:CreateMemberResultAnnotation xmlns:bbb=\"http://www.google.com\"><ResultHeader><abc:Version>1.0</abc:Version><abc:ResultNumber>1000</abc:ResultNumber><abc:ResultOutcome>Complete.</abc:ResultOutcome><abc:ResultReason>New Result</abc:ResultReason></ResultHeader><bbb:ActivationTime>20200111215217</bbb:ActivationTime><bbb:MemberInst><add:MemberKey><add:MemberID>123458687</add:MemberID><add:MemberSeq>0987654332456</add:MemberSeq></add:MemberKey><add:ActivationTime>20200111215217</add:ActivationTime><add:DeativationTime>20370101000000</add:DeativationTime></bbb:MemberInst><bbb:MemberInst><add:MemberKey><add:MemberID>0987699544</add:MemberID><add:MemberSeq>999999999999999</add:MemberSeq></add:MemberKey><add:ActivationTime>20200111215217</add:ActivationTime><add:DeativationTime>20370101000000</add:DeativationTime></bbb:MemberInst><bbb:MemberInst><add:MemberKey><add:MemberID>4444444444</add:MemberID><add:MemberSeq>4444444444444</add:MemberSeq></add:MemberKey><add:ActivationTime>20200111215217</add:ActivationTime><add:DeativationTime>20370101000000</add:DeativationTime></bbb:MemberInst></bbb:CreateMemberResultAnnotation></soapenv:Body></soapenv:Envelope>";
		//		//
		//		//			String sruresponse = getSruResponse(sruurl, repid);
		//		//			CreateRosettaLogStructMap.getContentFromDocument(sruresponse,"getiepidforrep");
		//		//			if (CreateRosettaLogStructMap.iepidfromrep!=null) {
		//		//				System.out.println("iepidfromrep: "+CreateRosettaLogStructMap.iepidfromrep);
		//		//			}
		//		//		} catch (Exception e) {
		//		//			// TODO Auto-generated catch block
		//		//			e.printStackTrace();
		//		//		}
		//		//
//						String wsurl = "http://maia.beic.it:1801/dpsws/repository/IEWebServices";
//						String user = "admin1";
//						String password = "a12345678A";
//						String institution = "TRN01";
//						//String iepidfortest = "IE9753"; --> errors on 39BEIC sandbox in TRN01 (IE21780)
//						String iepidfortest = "IE18909"; // IE1029 --> working on 39BEIC sandbox in TRN01
//						String repmid = "REP9754-1"; // 39BEIC sandbox in TRN01
//						try {
////							String soaptest = getIeXmlViaSoap(wsurl, user, password, institution, iepidfortest);
//							String soaptest = getLogicalStructmapViaSoap(wsurl, user, password, institution, repmid);
//							//TEST					String soaptest = getSoapResponse(wsurl, user, password, institution, iepidfortest);
//							System.out.println("soaptest: "+soaptest);
//				
////							String repId = "REP53308";
//							//String repId = "REP9754";
////							try {
////								//			String soaptest = "";
////								getFileNameIdFromPhysicalStructMap(soaptest, repId);
////							} catch (Exception e) {
////								// TODO Auto-generated catch block
////								e.printStackTrace();
////							}
//				
//						} catch (MalformedURLException e) {
//							e.printStackTrace();
//						} catch (IOException e) {
//							e.printStackTrace();
//						}
		//				//TEST	updateMD	String repidfortest = "REP53308";
		//				String repidfortest = "REP53308";
		//				try {
		//					String contentxmlfortest = "<mets:structMap  xmlns:mets=\"http://www.loc.gov/METS/\" ID=\"REP53308\" TYPE=\"LOGICAL\"><mets:div LABEL=\"rep label\"><mets:div LABEL=\"toc\"><mets:div LABEL=\"part1\"><mets:div LABEL=\"subpart11\"><mets:div LABEL=\"chapter111\"><mets:div LABEL=\"subchapter1111\"><mets:div LABEL=\"001\" TYPE=\"FILE\"><mets:fptr FILEID=\"FL53309\"/></mets:div></mets:div></mets:div></mets:div></mets:div></mets:div></mets:div></mets:structMap>";	
		//					String soaptest = addMdViaSoap(wsurl, user, password, institution, repidfortest, contentxmlfortest, "false", "mets_section", "structMap");
		//					//TEST					String soaptest = getSoapResponse(wsurl, user, password, institution, iepidfortest);
		//					System.out.println("soaptest: "+soaptest);
		//					if (soaptest!=null && !soaptest.contains("<soap:Fault>")) {
		//						System.out.println("Metadata added to " +repidfortest + ".");
		//					} else {
		//						System.out.println("soaptest: FAILED");
		//						throw new Exception("Adding metadata to " +repidfortest + " failed: " + soaptest);
		//					}		
		//				} catch (MalformedURLException e) {
		//					e.printStackTrace();
		//				} catch (IOException e) {
		//					e.printStackTrace();
		//				} catch (Exception e) {
		//					// TODO Auto-generated catch block
		//					e.printStackTrace();
		//				}
	
	
	}
}