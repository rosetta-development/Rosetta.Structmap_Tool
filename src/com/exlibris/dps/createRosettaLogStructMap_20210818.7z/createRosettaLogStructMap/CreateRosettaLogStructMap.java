package com.exlibris.dps.createRosettaLogStructMap;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;

public class CreateRosettaLogStructMap 
{
	static private enum SECTIONS { general, csvGeneration, xmlGeneration, dialogtext };
	static private final Logger logger = Logger.getLogger(CreateRosettaLogStructMap.class);
	static private XMLProperty properties;
	static private String selectedoption = "0";
	static private String repid;
	static private String iepidfromrep = null;
	static private String srubase;
	static private String wsurl;

	static private String csvreadyforxml;
	static private String userid;
	static private String password;
	static private String institutioncode;
	static private String labelregex;
	static private String structmaplevels;
	static private String xmlforcsv;
	static private String csvfromxml;
	static private String xmlreadyforupload;
	static private String repidsforcsv;
	static private String currentDir;
	static private String tooloption1;
	static private String tooloption2;
	static private String tooloption3;
	static private String tooloption4;
	static private String tooloption5;
	static private String tooloption6;
	static private String tooloption7;
	static private String tooloption8;
	static private int defaultoption = 0;
	static boolean copyxmltoclipboard = false;
	static boolean debug = false;
	static boolean windows = false;
	static private LogWindow logwindow;
	static private String separator = "\\";

	public CreateRosettaLogStructMap() throws Exception
	{
		get_properties();
	}

	//	@SuppressWarnings({ "deprecation", "static-access" })
	protected void finalize() throws Exception
	{
		logwindow.showInfo("END");
		logger.removeAllAppenders();
	}

	/*
	 * Unique exception formatting
	 */
	private void format_exception(Exception e)
	{
		StackTraceElement[] st = e.getStackTrace();
		for (StackTraceElement se : st)
		{
			if(se.getClassName().contains(this.getClass().getSimpleName()))
			{
				logger.error(e.getClass().getSimpleName() + " = \"" + e.getMessage() + "\" (triggered by " + se.getClassName() + ":" + se.getLineNumber() + ")");
				break;
			}
		}
	}

	/*
	 * Read properties from external file
	 */
	private	void get_properties() throws Exception
	{
		properties = new XMLProperty();
		String pn = "conf/" + this.getClass().getSimpleName() + ".xml";
		properties.load(pn);
		List<String> lines = Files.readAllLines(Paths.get(pn));
		currentDir = System.getProperty("user.dir");
		debug = Boolean.parseBoolean(properties.getProperty(SECTIONS.general.toString(), "debug"));
		logger.info("Following parameters have been set in ");
		logger.info("==> " + currentDir + "/" + pn + ":");
		logger.info("------------------------------------------------------");
		for(String line : lines) {
			if (line.replaceAll(" ", "").startsWith("<") && !line.replaceAll(" ", "").startsWith("<!")) {
				logger.info(line);
			}
		}
		logger.info("------------------------------------------------------" + System.lineSeparator());
	}

	/*
	 * Check arguments
	 * Read parameters from configuration file
	 */
	private	void get_parameters() throws Exception
	{
		xmlforcsv = properties.getProperty(SECTIONS.csvGeneration.toString(), "xmlforcsv");
		if (xmlforcsv==null || (xmlforcsv!=null && xmlforcsv.isEmpty())) {
			String info = "Folder for downloaded XML files is not configured - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		} else xmlforcsv = correct_folder(xmlforcsv);
		
		csvfromxml = properties.getProperty(SECTIONS.csvGeneration.toString(), "csvfromxml");
		if (csvfromxml==null || (csvfromxml!=null && csvfromxml.isEmpty())) {
			String info = "Folder for CSV files is not configured - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		} else csvfromxml = correct_folder(csvfromxml);
		
		structmaplevels = properties.getProperty(SECTIONS.csvGeneration.toString(), "structmaplevels");
		if (structmaplevels==null || (structmaplevels!=null && structmaplevels.isEmpty()) || (!structmaplevels.isEmpty() && StringUtils.countMatches(structmaplevels, ",")<2)) {
			String info = "At least three structure map levels must be configured - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		}
		
		labelregex = properties.getProperty(SECTIONS.csvGeneration.toString(), "labelregex");

		copyxmltoclipboard = Boolean.parseBoolean(properties.getProperty(SECTIONS.csvGeneration.toString(), "copyxmltoclipboard"));

		repidsforcsv = properties.getProperty(SECTIONS.csvGeneration.toString(), "repidsforcsv");
		
		csvreadyforxml = properties.getProperty(SECTIONS.xmlGeneration.toString(), "csvreadyforxml");
		if (csvreadyforxml==null || (csvreadyforxml!=null && csvreadyforxml.isEmpty())) {
			String info = "Folder containing CSV files for conversion to XML is not configured - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		} else csvreadyforxml = correct_folder(csvreadyforxml);

		xmlreadyforupload = properties.getProperty(SECTIONS.xmlGeneration.toString(), "xmlreadyforupload");
		if (xmlreadyforupload==null || (xmlreadyforupload!=null && xmlreadyforupload.isEmpty())) {
			String info = "Target folder for XML files is not configured - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		} else xmlreadyforupload = correct_folder(xmlreadyforupload);

		srubase = properties.getProperty(SECTIONS.general.toString(), "srubase");
		if (srubase==null || (srubase!=null && srubase.isEmpty())) {
			String info = "Base URL for SRU needs to be configured - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		}

		wsurl = properties.getProperty(SECTIONS.general.toString(), "wsurl");
		if (wsurl==null || (wsurl!=null && wsurl.isEmpty())) {
			wsurl = JOptionPane.showInputDialog("Please enter staff user ID:");
			String info = "WS URL "+wsurl+" has been entered.";
			add_loginfo(info, true);
		}

		userid = properties.getProperty(SECTIONS.general.toString(), "userid");
		if (userid==null || (userid!=null && userid.isEmpty())) {
			userid = JOptionPane.showInputDialog("Please enter staff user ID:");
			String info = "User ID "+userid+" has been entered.";
			add_loginfo(info, true);
		}

		password = properties.getProperty(SECTIONS.general.toString(), "password");
		if (password==null || (password!=null && password.isEmpty())) {
			password = JOptionPane.showInputDialog("Please enter staff user password:");
			String info = "User password has been entered.";
			add_loginfo(info, true);
		}

		institutioncode = properties.getProperty(SECTIONS.general.toString(), "institutioncode");
		if (institutioncode==null || (institutioncode!=null && institutioncode.isEmpty())) {
			institutioncode = JOptionPane.showInputDialog("Please enter institution code:");
			String info = "Institution code "+institutioncode+" has been entered.";
			add_loginfo(info, true);
		}

		tooloption1 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption1");
		tooloption2 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption2");
		tooloption3 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption3");
		tooloption4 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption4");
		tooloption5 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption5");
		tooloption6 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption6");
		tooloption7 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption7");
		tooloption8 = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption8");
		defaultoption = Integer.parseInt(properties.getProperty(SECTIONS.dialogtext.toString(), "defaultoption"));
		if (defaultoption-1<=0) defaultoption = 1;
	}

	private static String correct_folder(String folder) throws Exception
	{
		if (folder.endsWith("\\")||folder.endsWith("/")) {
			folder = folder.substring(0, (folder.length()-1));
		}

		return folder + separator;
	}	

	private static void add_loginfo(String info, boolean newline) throws Exception
	{
		if (newline) {
			logger.info(info + System.lineSeparator());
			logwindow.showInfo(info + System.lineSeparator());
		} else {
			logger.info(info);
			logwindow.showInfo(info);
		}
	}	

	/*
	 * for testing
	 * transforms XML W3C document to string
	 * */
	public static String getStringFromDocument(Document doc) throws TransformerException {
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		return writer.toString();
	}

	/*
	 * read XML
	 * get content and set variable
	 */
	public static void getContentFromDocument(String responsexml, String tagtoextract) throws Exception
	{
		Document xmlDocument = readXmlFromString(responsexml);
		Element root = xmlDocument.getDocumentElement();
		NodeList nl = root.getChildNodes();

		iepidfromrep=null;
		if (tagtoextract.equalsIgnoreCase("getiepidforrep")) {
			for(int k=0;k<nl.getLength();k++){
				getIePid((Node)nl.item(k));
			}
		}
	}	

	/*
	 * parse SRU response XML snippet
	 * identify IE PID for given REP ID
	 */
	public static void getIePid(Node nodes){
		if(nodes.hasChildNodes()&&iepidfromrep==null) {
			if (nodes.getNodeName().equals("dc:identifier") && nodes.getTextContent().matches("IE[0-9].*")) {
				iepidfromrep = nodes.getTextContent(); //set value of variable
				if (debug) logger.debug("iepidfromrep: "+iepidfromrep);
			}
			NodeList nl=nodes.getChildNodes();
			for(int j=0;j<nl.getLength();j++) {
				getIePid(nl.item(j));
			}
		}
	}

	/* 
	 * read XML from string (get DocumentBuilder object from string)
	 */
	public static Document readXmlFromString(String xml) throws Exception
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xml));
		return builder.parse(is);
	}

	/*
	 *  Check and create target directory if needed
	 */
	private void add_folder(String targetdir) throws Exception
	{
		File rootdir = new File(targetdir);
		if (!rootdir.exists())
		{
			String info = "Creating directory " + targetdir;
			add_loginfo(info, true);
			rootdir.mkdirs();
			if(!rootdir.exists())
				info = "Unable to create directory \"" + rootdir.getAbsolutePath() + "\"";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		}
	}

	/*
	 * Build and write CSV
	 */
	private static void build_and_write_csv_from_physical(String repid, ArrayList<String> alFileNameId) throws Exception
	{
		/*
		 * new CSV lines are added to string array 'NewCSV'
		 * 'NewCSV' is written to file 'csvname' in 'csvfromxml'
		 */
		ArrayList<String> NewCSV = new ArrayList<String>();
		String headerline = new String();
		ArrayList<String> repLabels = new ArrayList<String>();
		String replabels = new String();
		String fileline = new String();
		String csvname = new String();

		String newline = System.getProperty("line.separator"); // this will take proper line break depending on OS

		repLabels = SoapRequestClient.repLabels;
		for (String tmp : repLabels) {
			replabels = replabels + tmp + ",";
		}
		structmaplevels = structmaplevels.trim();
		if (structmaplevels.startsWith(",")) {
			structmaplevels = structmaplevels.substring(1, structmaplevels.length());
		}
		if (structmaplevels.matches(".*,$")) {
			structmaplevels = structmaplevels.substring(0, structmaplevels.length()-1);
//TEST			tmpout("structmaplevels: ",structmaplevels);
//TEST			throw new Exception("test");
		}
		
		headerline = structmaplevels
		             + ","+ "File ID";

		//calculate commas to add
		String filecommas = "";
		for(int i=2;i<StringUtils.countMatches(structmaplevels, ",");i++) filecommas = filecommas + ",";//first two levels are for replabels
		
		NewCSV.add(headerline);

		//create and add file lines
		for(int j=0;j<alFileNameId.size()-1;j++) {
			fileline = replabels+filecommas+get_label_from_filename(alFileNameId.get(j))+","+alFileNameId.get(j+1);
			NewCSV.add(fileline);
			j = j+1;
		}

		csvname = repid+".csv";
		FileWriter writecsv = new FileWriter(csvfromxml + csvname);
		String info = "New CSV file: '" + csvfromxml + csvname + "'.";
		add_loginfo(info, true);
		for (int k=0; k<NewCSV.size(); k++)
		{
			if (debug) logger.debug("add line: " + NewCSV.get(k));
			writecsv.write(NewCSV.get(k)+ newline);
		}
		writecsv.close();
		NewCSV.clear();
	}

	/*
	 * Build and write CSV from LOGICAL
	 */
	private static void build_and_write_csv_from_logical(String repmid, ArrayList<String> csvLinesFromXmlFile) throws Exception
	{
		/*
		 * part for file line was generated via ConvertLogicalXmlToCsv.createCsvFromLogicalXML(pathtoxmlfile)
		 * new CSV lines are added to string array 'NewCSV'
		 * 'NewCSV' is written to file 'csvname' in 'csvfromxml'
		 */
		ArrayList<String> NewCSV = new ArrayList<String>();
		String headerline = new String();
		String csvname = new String();

		String newline = System.getProperty("line.separator"); // this will take proper line break depending on OS

		//calculate header line - Level 1 to Level n + File ID
		for (int i=0; i<ConvertLogicalXmlToCsv.depthxml-1; i++) {
			headerline = headerline + "Level " + i + ",";
		}
		headerline = headerline + "File ID";

		NewCSV.add(headerline);
		
		//add file lines
		for(String fileline : csvLinesFromXmlFile) {
			NewCSV.add(fileline);
		}

		csvname = repmid+".csv";
		FileWriter writecsv = new FileWriter(csvfromxml + csvname);
		String info = "New CSV file: '" + csvfromxml + csvname + "'.";
		add_loginfo(info, true);
		for (int k=0; k<NewCSV.size(); k++)
		{
			if (debug) logger.debug("add line: " + NewCSV.get(k));
			writecsv.write(NewCSV.get(k)+ newline);
		}
		writecsv.close();
		NewCSV.clear();
	}

	/*
	 * extract label from filename via regular expression
	 * if no regex is configured, copy complete filename
	 */
	private static String get_label_from_filename(String filename) throws Exception
	{
		String filelabel = filename;
		try {
			if (labelregex != null) {
				Pattern p = Pattern.compile(labelregex);
				Matcher m = p.matcher(filename);
				while (m.matches()) {
					filelabel = m.group(1);
					if (debug) logger.debug("filelabel: " + filelabel);
					return filelabel;
				}
			}
		} catch (PatternSyntaxException e) {
			e.printStackTrace();
			String info = "Regex pattern syntax exception. Please check <labelregex>" 
					+ labelregex + "</labelregex> in CreateRosettaLogStructMap.xml.";
			add_loginfo(info, true);
		}
		return filelabel;
	}		


	/*
	 * Start creating structmap xml
	 * search folder that contains adjusted CSV file
	 * read CSV into list if string arrays 'contentcsv'
	 */
	private static void create_xml_files(String repid) throws Exception
	{
		String basename = new String();
		File files_dir = new File(csvreadyforxml);
		File[] files = files_dir.listFiles();
		boolean processing = false;

		if (files!=null) { 
			for( File file : files ) {
				String filename = file.getName();
				if (repid!=null && filename.toUpperCase().matches(".*\\.CSV")) { //process only one CSV
					basename = filename.substring(0, filename.lastIndexOf("."));
//					tmpout("basename",basename);
					if (filename.equalsIgnoreCase(repid+".csv")) {
						List<String[]> contentcsv = read_csv_file(file); // read one CSV
						String info = "Processing CSV '" + csvreadyforxml + filename + "'.";
						add_loginfo(info, true);
						write_xml(contentcsv, basename, true); // write one XML
						processing = true;
					} else continue;
				}
				if (filename.toUpperCase().matches("REP.*\\.CSV") && repid==null) { //process all CSV
					basename = filename.substring(0, filename.lastIndexOf("."));
					List<String[]> contentcsv = read_csv_file(file); // read one CSV
					String info = "Processing CSV '" + csvreadyforxml + filename + "'.";
					add_loginfo(info, true);
					write_xml(contentcsv, basename, false); // write multiple XML -> batch processing, i.e. no copy of XML into cache
					processing = true;
				}
			}
			if (!processing) {
				String info = "There is no CSV file for " + repid + " in " + csvreadyforxml + ". Please check!";
				logwindow.showInfo("ERROR - " + info + System.lineSeparator());
				throw new Exception(info);
			}
		} else {
			String info = "There are no CSV files in " + csvreadyforxml + ". Please check!";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		}
	}

	/*
	 * read in the CSV and transform to array
	 */
	private static List<String[]> read_csv_file(File file) throws Exception
	{
		List<String[]> contentcsv = new ArrayList<>();		
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line;
		reader.readLine();//ignore first line (header line)
		while ((line = reader.readLine()) != null) {
			contentcsv.add(line.split(","));
		}
		reader.close();
		return contentcsv;
	}


	private static void write_xml(List<String[]> contentcsv, String basename, boolean singlexml) throws Exception
	{
		String newline = System.getProperty("line.separator"); // this will take proper line break depending on OS
		String xmlname = basename + ".xml"; //basename equals the REP (M)ID
		ArrayList<String> NewXML = new ArrayList<String>();
		String closediv = "</mets:div>";
		String closerepdiv = "";
		String closestructmap = "</mets:structMap>";

		String info = "New XML file: '" + xmlreadyforupload + xmlname;
		add_loginfo(info, true);
		FileWriter writexml = new FileWriter(xmlreadyforupload + xmlname);

		boolean donefileexists = new File(xmlreadyforupload, xmlname+".done").exists();
		if (donefileexists) {
			info = "NOTE: File '" + xmlreadyforupload + xmlname + ".done' " + "exists. A structure map had been added to this REP, before.";
			add_loginfo(info, true);
		}

		/*
		 * initiate current DIVs matrix: no DIVs are open
		 */
		String[] CurrentFileDivMatrix = new String[contentcsv.get(0).length];
		for(int l=0;l<CurrentFileDivMatrix.length;l++) {
			CurrentFileDivMatrix[l] = "no";
		}

		String structmapline = "<mets:structMap xmlns:mets=\"http://www.loc.gov/METS/\" ID=\""+basename+"\" TYPE=\"LOGICAL\">";
		NewXML.add(structmapline);
		for(int j=0;j<contentcsv.size();j++) { //process complete CSV
			String[] csvline = contentcsv.get(j);
			String[] filelinematrix = new String[contentcsv.get(0).length-2];
//			if (csvline[0].equals("FILE")) { //read only FILE lines
				for (int n=0; n<csvline.length-2; n++) {//iterate through all columns except of last (i.e. 'File ID')
					if (csvline[n].isEmpty()) {
						filelinematrix[n] = "no"; // nothing to do
					} else filelinematrix[n] = "yes"; // DIV is opened on this level
				}

				/*
				 * compare filelinematrix with CurrentFileDivMatrix:
				 * if DIV in line is opened, check if there are any open DIVs on same or lower level, and close them
				 */
				String filetag = "";//file
				String completeline = "";//complete line
				int filedivs = filelinematrix.length;
//				tmpout("filedivs",Integer.toString(filedivs));
				for (int n=0; n<filedivs; n++) {
					if (filelinematrix[n]=="yes") {
						completeline = completeline + write_metsdiv(csvline[n], n); // write <mets:div LABEL="{csvline[n+5]}">
						for (int p=n; p<filedivs; p++) {//check against current and following (i.e. lower) levels
							if (debug) {
								logger.debug("line "+(j-1)+" -- "+"filelinematrix-n["+n+"]: "+filelinematrix[n]+" -- "+"CurrentFileDivMatrix-p["+p+"]: "+CurrentFileDivMatrix[p]);
							}
							if (CurrentFileDivMatrix[p]=="yes") {
								completeline = closediv + completeline; //close this level
								CurrentFileDivMatrix[p] = "no"; //indicate that this level was closed
							}
						}
						CurrentFileDivMatrix[n] = "yes";
					}
				}

				if (!csvline[csvline.length-2].isEmpty()) {//file label exists
					String csvcell = csvline[csvline.length-2];
//					if (!csvcell.isEmpty()) {
//						if (csvcell.matches("^\".*\"$")) { //content is in hyphens "..."
//							csvcell = csvcell.replaceAll("^\"", "");
//							csvcell = csvcell.replaceAll("\"$", "");
//						}
//					}
					filetag = "<mets:div xxxxLABEL=\"" + csvcell + "\" TYPE=\"FILE" + "\">" 
							+ "<mets:fptr FILEID=\"" + csvline[csvline.length-1] + "\"/>" + closediv;
				} else {
					/*
					 * special case: file label is also used as structmap label (e.g. 'Frontespizio')
					 * find last label and transform it to file label
					 */
					for (int n=csvline.length-2; n>0; n--) {
						if (!csvline[n].isEmpty()) {
							String csvcell = csvline[n];
//							if (!csvcell.isEmpty()) {
//								if (csvcell.matches("^\".*\"$")) { //content is in hyphens "..."
//									csvcell = csvcell.replaceAll("^\"", "");
//									csvcell = csvcell.replaceAll("\"$", "");
//								}
//							}
							filetag = "<mets:fptr FILEID=\"" + csvcell + "\"/>" + closediv;
							completeline = completeline.replaceFirst(">$", " TYPE=\"FILE\""+">");
							CurrentFileDivMatrix[n] = "no";
						}
					}

				}
				NewXML.add(completeline + filetag);
//			}
		}
		/*
		 * close all open DIVs from file level
		 */
		String closingdivs="";
		for (int r=0; r<CurrentFileDivMatrix.length; r++) {//check for open DIVs
			if (CurrentFileDivMatrix[r]=="yes") {
				closingdivs = closingdivs + closediv; //close this level
			}
		}
		NewXML.add(closingdivs);

//		NewXML.add(closerepdiv);//close REP level DIVs
		NewXML.add(closestructmap);//close structure map

		for (int k=0; k<NewXML.size()-1; k++)//write XML (except last line)
		{
			writexml.write(NewXML.get(k)+ newline);
		}
		writexml.write(NewXML.get(NewXML.size()-1));//write last line
		writexml.close();
		contentcsv.clear();

		//copy to clipboard
		if (singlexml && copyxmltoclipboard && !NewXML.isEmpty()) {
			String structmapxml = NewXML.toString();
			structmapxml = structmapxml.substring(1, structmapxml.length()-1).replaceAll(">, <", "><");
			StringSelection stringSelection = new StringSelection(structmapxml);
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(stringSelection, null);
		}
	}

	private static String write_metsdiv(String csvcell, int n) throws Exception
	{
		if (!csvcell.isEmpty()) {
			if (csvcell.matches("^\".*\"$")) { //content is in hyphens "..."
				csvcell = csvcell.replaceAll("^\"", "");
				csvcell = csvcell.replaceAll("\"$", "");
			}
			String metsdivopenerstart = "<mets:div X"+n+"LABEL=\"";
			String metsdivopenerend = "\">";
			String metsdiv = metsdivopenerstart+csvcell+metsdivopenerend;
			return metsdiv;
		} else return csvcell;
	}


	private static void display_selected_option(String selectedoption) throws Exception
	{
		String info = "Selected option: " + selectedoption;
		add_loginfo(info, true);
		add_loginfo("----------", true);
	}

	/*
	 * Start update of REPs
	 * search folder that contains created structure map XML files
	 * read XML, call update via soap, check result
	 */
	private static void update_repository_object(String repidormid) throws Exception
	{
		String updateresult = new String();
		File files_dir = new File(xmlreadyforupload);
		File[] files = files_dir.listFiles();

		if (repidormid!=null && files!=null) { 
			String info = "Processing XML files in '" + xmlreadyforupload + "'.";
			add_loginfo(info, true);
			add_loginfo("***************", true);
			for( File file : files ) {
				String filename = file.getName();
				if (filename.contains(".xml")) { 
					boolean donefileexists = new File(xmlreadyforupload, filename+".done").exists();
					if (donefileexists) {
						info = repidormid + " - ERROR Update via API - : "  + filename + ".done' " + "exists already.";
						add_loginfo(info, true);
						break;
					}
					if (filename.equalsIgnoreCase(repidormid+".xml")) {
						add_loginfo("", true);
						String structmapxml = Files.lines(Paths.get(xmlreadyforupload, filename)).collect(Collectors.joining("\n"));
						updateresult = SoapRequestClient.addMdViaSoap(wsurl, userid, 
								password, institutioncode, repidormid, structmapxml, "true", "mets_section", "structMap"); // update REP
					} else {
						info = "There is no XML file for " + repidormid + " in " + xmlreadyforupload + ". Please check!";
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
					String updateerror = check_result_of_update(updateresult);
					if (updateerror != null) {
						info = repidormid + " - ERROR Update via API - : " + updateerror;
						add_loginfo(info, true);
					} else {
						info = repidormid + " - SUCCESS Update via API - ";
						add_loginfo(info, true);
						Path fileToMovePath = Paths.get(xmlreadyforupload, filename);
						Path targetPath = Paths.get(xmlreadyforupload, filename+".done");
						try {
							renameFile(fileToMovePath, targetPath); //rename file to avoid double processing
						} catch (IOException e) {
							info = repidormid + " - ERROR Renaming - file already exists: " + e.getMessage();
							add_loginfo(info, true);
							e.printStackTrace();
						}
					}
				}
			}
		}
	}

	private static String check_result_of_update(String updateresult) throws Exception
	{
		//...<soap:Body><ns2:updateMDResponse xmlns:ns2="http://dps.exlibris.com/"/></soap:Body>... indicates successful update
		if (updateresult.contains("updateMDResponse")) {
			updateresult = null;
			return updateresult;
		}
		if (updateresult.contains("<faultstring>")) {
			updateresult = updateresult.substring(updateresult.indexOf("<faultstring>")+13, updateresult.indexOf("</faultstring>"));
			return updateresult;
		}
		return updateresult;
	}

	private static void renameFile(Path fileToMovePath, Path targetPath) throws IOException 
	{
		Files.move(fileToMovePath, targetPath); //rename file to avoid double processing
	}

	private static void tmpout(String name, String value) throws IOException 
	{
		System.out.println(name+": "+value);
	}

	private static void writeFile(String folder, String filename, String content) throws Exception, IOException 
	{
		String info = "Writing file: '" + folder + filename + "'";
		add_loginfo(info, true);
		FileWriter writexml = new FileWriter(folder + filename);
		
		writexml.append(content);
		writexml.close();
	}

	/*
	 * 
	 */
	private static void create_csv_from_logical_structmap(String repmid) throws Exception, IOException
	{
		//request logical structure map via soap
		String soapresponse = null;
		try {
			soapresponse = SoapRequestClient.getLogicalStructmapViaSoap(wsurl, userid, password, institutioncode, repmid);
		} catch (IOException e) {
			String info = "ERROR - " + e.getMessage();
			add_loginfo(info, true);
		}
		if (soapresponse != null && !soapresponse.contains("<faultstring>")) {
			if (debug) logger.debug("soapresponse: "+soapresponse);
			try {
				//write response to xml into folder <xmlforcsv>
				writeFile(xmlforcsv, repmid + ".xml", soapresponse);
			} catch (Exception e) {
				String info = "ERROR - " + e.getMessage();
				add_loginfo(info, true);
				throw new Exception("ERROR - " + "XML for " + repmid + " could not be written - tool stopped processing");
			}
		} else {
			String info = "Data for " + repmid + " could not be received - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		}

		//convert XML to CSV
		String pathtoxmlfile = xmlforcsv + repmid + ".xml";	
		ArrayList<String> csvLineFromXmlFile = ConvertLogicalXmlToCsv.convertLogicalXmlToCsv(pathtoxmlfile);
		if (csvLineFromXmlFile != null) {
			build_and_write_csv_from_logical(repmid, csvLineFromXmlFile);
		}
	}

	private static void create_csv_from_physical_structmap(String repid) throws Exception, IOException
	{
		String sruurl;
		String sruoperation = "operation=searchRetrieve&startRecord=1";
		String sruquery = "&query=REP.internalIdentifier.internalIdentifierType.PID=";
		sruurl = srubase+sruoperation+sruquery;
		if (debug) logger.debug("sruurl: "+sruurl);
		if (debug) logger.debug("repid: "+repid);
		//TEST			String sruresponse = "<searchRetrieveResponse xmlns=\"http://www.loc.gov/zing/srw/\"><version>1.2</version><numberOfRecords>1</numberOfRecords><records><record><recordSchema>info:srw/schema/1/dc-v1.1</recordSchema><recordPacking>xml</recordPacking><recordData><dc:record xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:dcterms=\"http://purl.org/dc/terms/\"><dc:creator xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">test_2.1</dc:creator><dc:title xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">test_2.1</dc:title><dc:description xml:lang=\"English\" xsi:type=\"pages\" xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">test_2.1</dc:description><dc:type xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">Manuscripts</dc:type><dcterms:created xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">14/09/2010</dcterms:created><dc:publisher xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\"/><dc:description xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\"/><dc:creator xmlns:mods=\"http://www.loc.gov/mods/v3 http://www.loc.gov/standards/mods/v3/mods-3-0.xsd\" xmlns:mets=\"http://www.loc.gov/METS/\">Nir Sherwinter</dc:creator><dc:identifier xsi:type=\"PID\">IE1000</dc:identifier><dc:rights>6683</dc:rights><dc:identifier xsi:type=\"entityType\">Picture</dc:identifier><dc:identifier xsi:type=\"stream\">https://rosetta.exlibrisgroup.com:443/delivery/DeliveryManagerServlet?dps_pid=IE1000</dc:identifier><dc:identifier xsi:type=\"thumbnail\">https://rosetta.exlibrisgroup.com:443/delivery/DeliveryManagerServlet?dps_pid=IE1000&amp;dps_func=thumbnail</dc:identifier></dc:record></recordData><recordPosition>1</recordPosition></record></records></searchRetrieveResponse>";
		//TEST			String test = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><bbb:CreateMemberResultAnnotation xmlns:bbb=\"http://www.google.com\"><ResultHeader><abc:Version>1.0</abc:Version><abc:ResultNumber>1000</abc:ResultNumber><abc:ResultOutcome>Complete.</abc:ResultOutcome><abc:ResultReason>New Result</abc:ResultReason></ResultHeader><bbb:ActivationTime>20200111215217</bbb:ActivationTime><bbb:MemberInst><add:MemberKey><add:MemberID>123458687</add:MemberID><add:MemberSeq>0987654332456</add:MemberSeq></add:MemberKey><add:ActivationTime>20200111215217</add:ActivationTime><add:DeativationTime>20370101000000</add:DeativationTime></bbb:MemberInst><bbb:MemberInst><add:MemberKey><add:MemberID>0987699544</add:MemberID><add:MemberSeq>999999999999999</add:MemberSeq></add:MemberKey><add:ActivationTime>20200111215217</add:ActivationTime><add:DeativationTime>20370101000000</add:DeativationTime></bbb:MemberInst><bbb:MemberInst><add:MemberKey><add:MemberID>4444444444</add:MemberID><add:MemberSeq>4444444444444</add:MemberSeq></add:MemberKey><add:ActivationTime>20200111215217</add:ActivationTime><add:DeativationTime>20370101000000</add:DeativationTime></bbb:MemberInst></bbb:CreateMemberResultAnnotation></soapenv:Body></soapenv:Envelope>";

		String sruresponse = SoapRequestClient.getSruResponse(sruurl, repid);
		if (debug) logger.debug("sruresponse: "+sruresponse);
		if (sruresponse!=null && sruresponse.contains("<numberOfRecords>1</numberOfRecords>")) {
			getContentFromDocument(sruresponse,"getiepidforrep");
		} else {
			String info = "Data for " + repid + " could not be found - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		}

		//TEST			String wsurl = "https://rosetta.exlibrisgroup.com/dpsws/repository/IEWebServices";
		//TEST			String userid = "admin1";
		//TEST			String password = "a12345678A";
		//TEST			String institutioncode = "INS00";
		//TEST			String iepidfortest = "IE53307";
		String soapresponse = null;
		try {
			soapresponse = SoapRequestClient.getIeXmlViaSoap(wsurl, userid, password, institutioncode, iepidfromrep);
//TEST			soapresponse = SoapRequestClient.getIeXmlViaDelivery(iepidfromrep);
			
		} catch (IOException e) {
			String info = "ERROR - " + e.getMessage();
			add_loginfo(info, true);
		}
		if (soapresponse != null && !soapresponse.contains("<faultstring>")) {
			if (debug) logger.debug("soapresponse: "+soapresponse);
			ArrayList<String> alFilenameId = new ArrayList<String>(); //single string with iteration of file id and name
			try {
				alFilenameId = SoapRequestClient.getFileNameIdFromPhysicalStructMap(soapresponse, repid);
				for (String tmp : alFilenameId) {
					tmpout("------create_csv after clear----------alFileNameId: ",tmp);
				}
			} catch (Exception e) {
				String info = "ERROR - " + e.getMessage();
				add_loginfo(info, true);
				throw new Exception("ERROR - " + "Data for " + repid + " could not be received - tool stopped processing");
			}
			build_and_write_csv_from_physical(repid, alFilenameId);
		} else {
			String info = "Data for " + repid + " could not be received - tool stopped processing";
			logwindow.showInfo("ERROR - " + info + System.lineSeparator());
			throw new Exception(info);
		}
	}

	/*
	 * read file with REP IDs (one per line)
	 * start creation of CSV files
	 */
	private static void bulkcreate_csv(String repidsfile, boolean fromphysical) throws Exception
	{
		try {
			if (repidsfile != null) {
				BufferedReader reader = new BufferedReader(new FileReader(repidsfile));
				String line;
				while ((line = reader.readLine()) != null) {
					if (fromphysical) {
						create_csv_from_physical_structmap(line);
					} else {
						create_csv_from_logical_structmap(line);
					}
//					tmpout("bulkcreate_csv -- ",line);
				}
				reader.close();
			} else {
				String info = "ERROR - File " + repidsfile + " could not be found - tool stopped processing";
				add_loginfo(info, true);
				throw new Exception(info);
			}
		} catch (Exception e) {
			String info = "ERROR - " + e.getMessage();
			add_loginfo(info, true);
		}
	}
	
	
	public static void main(String[] args) {

		org.apache.log4j.helpers.LogLog.setQuietMode(true);
		CreateRosettaLogStructMap myself = null;

		try {
			if (!System.getProperty("os.name").startsWith("Windows")) {
				throw new Exception("This tool runs on Windows");
			}
			/* 
			 * let select option
			 * <tooloption1>Create CSV file from physical structure map for representation</tooloption1>
			 * <tooloption2>Batch process: Create CSVs from physical structure map for list of REP IDs</tooloption2>
			 * <tooloption3>Create CSV file from logical structure map for representation</tooloption3>
			 * <tooloption4>Batch process: Create CSVs from logical structure map for list of REP MIDs</tooloption4>
			 * <tooloption5>Create structure map XML from single prepared CSV</tooloption5>
			 * <tooloption6>Batch process: Create structure map XMLs from all prepared CSVs</tooloption6>
			 * <tooloption7>Add/update logical structure map for representation (via API)</tooloption7>
			 * <tooloption8>Batch process: Add/update structure maps (via API)</tooloption8>
			 * get rep ID via user input for option 1, 3, 5, 7
			 * 
			 */
			logwindow = new LogWindow();
			logwindow.showInfo("----Create logical structure maps for Rosetta----" + System.lineSeparator());
			logwindow.showInfo("--------------------------------------------------------------------------------" + System.lineSeparator());
			myself = new CreateRosettaLogStructMap();
			myself.get_parameters();
			myself.add_folder(xmlforcsv);
			myself.add_folder(csvfromxml);
			myself.add_folder(csvreadyforxml);
			myself.add_folder(xmlreadyforupload);
			String[] tooloptions = {
					"1 - " + tooloption1, 
					"2 - " + tooloption2, 
					"3 - " + tooloption3, 
					"4 - " + tooloption4, 
					"5 - " + tooloption5,
					"6 - " + tooloption6,
					"7 - " + tooloption7,
					"8 - " + tooloption8
			};

			String usercanceled = "User canceled - tool stopped processing";
			Object selected = JOptionPane.showInputDialog(null, "Following options exist:", "Selection", JOptionPane.DEFAULT_OPTION, null, tooloptions, tooloptions[defaultoption-1]);
			if ( selected != null ){//null if user cancels
				selectedoption = selected.toString();
				if (selectedoption.startsWith("1")) { //create CSV from PHYSICAL structure map
					display_selected_option(selectedoption);
					repid = "REP1281"; //JOptionPane.showInputDialog("Please enter Representation ID:");
					if (repid!=null) {
						create_csv_from_physical_structmap(repid.trim().toUpperCase());
					} else {
						String info = usercanceled;
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
				}
				if (selectedoption.startsWith("2")) { //create CSVs for all REP IDs from txt file
					display_selected_option(selectedoption);
					if (repidsforcsv!=null && !repidsforcsv.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Click OK to create CSV files for all REP IDs listed in "+repidsforcsv+".");
						bulkcreate_csv(repidsforcsv, true);
					} else {
						String info = "The path to REP IDs file is not configured - tool stopped processing";
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
				}
				if (selectedoption.startsWith("3")) { //create CSV from LOGICAL structure map
					display_selected_option(selectedoption);
					repid = "REP11599-1"; //JOptionPane.showInputDialog("Please enter Representation ID:");
					if (repid!=null) {
						create_csv_from_logical_structmap(repid.trim().toUpperCase());
					} else {
						String info = usercanceled;
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
				}
				if (selectedoption.startsWith("4")) { //create CSVs for all REP MIDs from txt file
					display_selected_option(selectedoption);
					if (repidsforcsv!=null && !repidsforcsv.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Click OK to create CSV files for all REP IDs listed in "+repidsforcsv+".");
						bulkcreate_csv(repidsforcsv, false);
					} else {
						String info = "The path to REP IDs file is not configured - tool stopped processing";
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
				}
				if (selectedoption.startsWith("5")) { //create single XML
					display_selected_option(selectedoption);
					repid = JOptionPane.showInputDialog("Please enter Representation ID:");
					if (repid!=null) {
						create_xml_files(repid.trim().toUpperCase());
					} else {
						String info = usercanceled;
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
				}
				if (selectedoption.startsWith("6")) { //create all XMLs
					display_selected_option(selectedoption);
					JOptionPane.showMessageDialog(null, "Click OK to process files in "+csvreadyforxml+".");
					create_xml_files(null);
				}
				if (selectedoption.startsWith("7")) { //update single REP via API
					display_selected_option(selectedoption);
					String repidormid = JOptionPane.showInputDialog("Please enter Representation ID or MID:");
					if (repidormid!=null) {
						repidormid = repidormid.trim().toUpperCase();
						if (repidormid.startsWith("REP")) {//valid ID
							update_repository_object(repidormid);
						} else {
							String info = "ID " + repidormid + " is not valid - tool stopped processing";
							logwindow.showInfo("ERROR - " + info + System.lineSeparator());
							throw new Exception(info);
						}
					} else {
						String info = usercanceled;
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
				}
				if (selectedoption.startsWith("8")) { //update all REPs via API
					display_selected_option(selectedoption);
					int confirm = JOptionPane.showConfirmDialog(null, "Click -Yes- to process all files in "+xmlreadyforupload+".");
					if (confirm==0) {
						update_repository_object(null);
					} else {
						String info = usercanceled;
						logwindow.showInfo("ERROR - " + info + System.lineSeparator());
						throw new Exception(info);
					}
				}
			} else {
				String info = usercanceled;
				logwindow.showInfo("ERROR - " + info + System.lineSeparator());
				throw new Exception(info);
			}

			//			repid = "REP53308";//TEST

			Instant startTime = Instant.now();
			Instant endTime = Instant.now();
			Duration d = Duration.between(startTime, endTime);
			long hoursPart = d.toHours(); 
			long minutesPart = d.minusHours( hoursPart ).toMinutes(); 
			long secondsPart = d.minusMinutes( minutesPart ).getSeconds() ;
			long millisecondsPart = d.minusSeconds(secondsPart).toMillis(); 
			add_loginfo("", true);
			add_loginfo("*****************************", true);
			add_loginfo(" **FINISHED processing**", true);
			add_loginfo("*****************************", true);
			String info = "Log files are in folder '" + currentDir + separator + "logs" + separator+ "'.";
			add_loginfo(info, true);
			add_loginfo("", true);
			add_loginfo("", true);
			info = "Processing time: " + hoursPart + "h:" + minutesPart +"min:"+ secondsPart + "." + millisecondsPart + "s";
			add_loginfo(info, true);
			add_loginfo("", true);
		} catch (Exception e) 
		{
			if (myself != null)
				myself.format_exception(e);
			else {
				logger.error(e.getLocalizedMessage()); 
				logwindow.showInfo("ERROR: " + e.getLocalizedMessage() + System.lineSeparator());
			}
		}
		if (myself != null)
			try {
				myself.finalize();
			} catch (Exception e) {};
	}
}
