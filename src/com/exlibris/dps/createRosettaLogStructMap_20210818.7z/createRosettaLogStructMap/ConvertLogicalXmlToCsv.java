package com.exlibris.dps.createRosettaLogStructMap;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ConvertLogicalXmlToCsv {

	public static int depthxml = 0;
	private static String csvLineFromXml02 = new String();;
	private static ArrayList<String> csvLineFromXml01 = new ArrayList<>();

	private static void printNode(NodeList nodeList, int level) {
		level++;
		if (nodeList != null && nodeList.getLength() > 0) {
			String fileid = "";
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					if (node.getAttributes()!=null) {
						if (node.getAttributes().getNamedItem("FILEID")!=null) {
							fileid = node.getAttributes().getNamedItem("FILEID").getNodeValue();
						}
					}
					if (level > 0) {
						String twodigitlevel = String.format("%02d", level);
						if (node.getAttributes().getNamedItem("LABEL")!=null) {
							String labeltmp = node.getAttributes().getNamedItem("LABEL").getNodeValue();
							String tmp = String.format(
									"%s%s::::%s;;;;%n",twodigitlevel, labeltmp, fileid);
							csvLineFromXml01.add(tmp);
						} else {
							String tmp = String.format(
									"%s%s::::%s;;;;%n",twodigitlevel, node.getAttributes().getNamedItem("LABEL"), fileid);
							csvLineFromXml01.add(tmp);
//							System.out.println("else csvLineFromXml01: " + tmp);
						}
					}
					printNode(node.getChildNodes(), level);
				}
			}
		}
	}

	private static boolean getMaxDepthXML(NodeList nodeList, int level) {
		level++;
		if (nodeList != null && nodeList.getLength() > 0) {
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					getMaxDepthXML(node.getChildNodes(), level);
					if (level > depthxml) {
						depthxml = level;
					}
				}
			}
		}
		boolean gotdepthxml = true;
		return gotdepthxml;
	}

	private static NodeList getNodeList(String xmlinput) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		NodeList nl = null;
		NodeList childNodes = null;
		try (InputStream is = new FileInputStream(xmlinput)) {
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(is);
			
			/*
			 * extract nodes below 
			 * <?xml version="1.0" encoding="UTF-8"?>
			 *   <mets:structMap ID="REP11599-1-MID-REP11599-1" TYPE="LOGICAL">
			 */
			XPathFactory xPathfactory = XPathFactory.newInstance();
			XPath xpath = xPathfactory.newXPath();
			XPathExpression expr = xpath.compile("//*[local-name()='mets']/*[local-name()='structMap'][@TYPE=\"LOGICAL\"]");
			nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET); //nodes of physical structure map
			childNodes = nl.item(0).getChildNodes();
		}
		catch (ParserConfigurationException | SAXException | IOException | XPathExpressionException e) {
			e.printStackTrace();
		}
		return childNodes;
	}

	public static ArrayList<String> convertLogicalXmlToCsv(String pathtoxmlfile) {
		NodeList childNodes = getNodeList(pathtoxmlfile);
		boolean gotdepthxml = getMaxDepthXML(childNodes, 0);
		if (gotdepthxml) {
			printNode(childNodes, 0);
		}
		for (String tmp : csvLineFromXml01) {
			tmp = StringEscapeUtils.escapeXml(tmp); //needed to keep for example &amp; in label
			tmp = tmp.replace("null::::", "::::");
			tmp = tmp.replace("::::;;;;", "::::");
			tmp = tmp.replace("::::FL", "FL");
			csvLineFromXml02 = csvLineFromXml02 + tmp;
		}
		String[] csvLineFromXml03 = csvLineFromXml02.split(";;;;");
		//	          for (int i=0; i<csvLineFromXml03.length; i++) {//TEST - check content of csvLineFromXml03
		//	        	  String tmp = csvLineFromXml03[i];
		//	        	  System.out.println("csvLineFromXml03["+i+"]: " + tmp);
		//	          }

		//create array of columns
		ArrayList<String[]> csvLineFromXml04 = new ArrayList<>();
		for (int i=0; i<csvLineFromXml03.length; i++) {
			String[] tmp = csvLineFromXml03[i].toString().split("::::"); //toString() is essential for splitting
			if (tmp.length>1) csvLineFromXml04.add(tmp); //without condition, an empty line would be added to the end of the list
		}

		//rearrange data from csvLineFromXml04 into csvLineFromXmlFile
		ArrayList<String> csvLineFromXmlFile = new ArrayList<>();
		for (String[] tmp : csvLineFromXml04) {
			//	        	  for (int j=0;j<tmp.length;j++) {//TEST - check content of csvLineFromXml04 array list
			//	        		  System.out.println("csvLineFromXml04["+j+"]: " + tmp[j].toString());  
			//	        	  }

			if (depthxml>=2) {
				String[] newtmp = new String[depthxml]; //create string array in the size of node depth of XML
				if (tmp.length>=2) {
					/*
					 * special case: file label is also used as structmap label (e.g. 'Frontespizio')
					 * --> keep this label in old position and add FILE attribute to the DIV when generating XML from CSV afterwards
					 * other option: keep this label in old position but also copy it to file label position
					 */
					int prefix = Integer.parseInt(tmp[tmp.length-2].trim().substring(0,2));
					//	        			  System.out.println("prefix: "+prefix);
					if (prefix >= (depthxml-3)) {
						newtmp[depthxml-2] = tmp[tmp.length-2].trim().substring(2).concat(","); //copy one before last entry (file label)
						tmp[tmp.length-2] = null;
					}
					newtmp[depthxml-1] = tmp[tmp.length-1].trim().substring(2); //copy last entry (file ID)
					tmp[tmp.length-1] = null;
					//    					  System.out.println("newtmp ["+(depthxml-1)+"]: "  + newtmp[depthxml-1]+"/"+tmp[tmp.length-1]);
				} else {
					for (int j=0;j<tmp.length;j++) {
						System.out.println("problematic tmp content/length: " + tmp[j]+"/"+tmp.length);  
					}
					continue;
				}
				for (int j=0;j<tmp.length;j++) { //move labels to right position according their XML node level
					if (tmp[j] != null) {
						for (int m=depthxml-2;m>0;m--) { // do it for all but last two
							String m2digits = String.format("%02d", m);
							//	        					  System.out.println("m2digits"+m2digits);
							String tmpj = tmp[j].trim(); //trim() is essential to remove some invisible characters from start of string
							if (tmpj.startsWith(m2digits)) {//copy label from tmp[] with specific start number to this position in newtmp[]
								tmpj = tmpj.replaceFirst(m2digits, "").concat(","); //remove level digit and add ',' after the label
								newtmp[m-1] = tmpj; 
								//	        						  System.out.println("IF newtmp ["+m+"]: "  + newtmp[m]+"/"+tmpj);
							}
						}
					}
				}
				for (int k=0;k<newtmp.length;k++) {
					//	        			  System.out.println("newtmp content/length: " + newtmp[k]+"/"+newtmp.length);
					if (newtmp[k]==null) newtmp[k] = ",";
				}

				StringBuilder builder = new StringBuilder ();
				String csvfileline;

				for (String s: newtmp) {
					builder.append(s);
				}
				csvfileline = builder.toString();
				csvLineFromXmlFile.add(csvfileline);
			}
		}	          
		//set all temp arrays to null
		csvLineFromXml02 = null;
		csvLineFromXml03 = null;
		csvLineFromXml04 = null;
//		for (String line : csvLineFromXmlFile) {//TEST - check content of csvLineFromXmlFile
//			System.out.println("csvline: " + line);
//		}
		return csvLineFromXmlFile;
	}

	public static void main(String args[]) {

//		String pathtoxmlfile = "C:\\Users\\jenss\\Desktop\\temp\\structmap_tool\\xml_from_soaprequest\\REP11599-1.xml";	
//		convertLogicalXmlToCsv(pathtoxmlfile);
	}
}