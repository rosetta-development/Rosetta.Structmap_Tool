package com.exlibris.dps.createRosettaLogStructMap;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.awt.datatransfer.StringSelection;
import java.awt.Cursor;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;

public class CreateRosettaLogStructMap 
{
	static boolean copyxmltoclipboard = false;
	static boolean debug = false;
	static boolean askforconfirmation = true;
	static boolean windows = false;
	static boolean missinguser = false;
	static boolean missingpassword = false;
	static boolean missinginstitution = false;
	static String repid;
	static String csvreadyforxml;
	static String userid;
	static String password;
	static String downloadedxml;
	static String xmlreadyforupload;
	static String repidsfordownload;
	static String repmidsfordownload;
	static String currentDir;
	static ArrayList<String> tooloptions = new ArrayList<String>();

	static final Logger logger = Logger.getLogger(CreateRosettaLogStructMap.class);
	static final String separator = "\\";
	
	static private enum SECTIONS { general, csvGeneration, xmlGeneration, dialogtext };
	static private int addlevels;
	static private XMLProperty properties;
	static private String iepidfromrep = null;
	static private String srubase;
	static private String wsurl;
	static private String institutioncode;
	static private String labelregex;
	static private String csvfromxml;
	static private String donefolder;

	public CreateRosettaLogStructMap() throws Exception
	{
		get_properties();
		for (int i=0; i<9; i++) {
			String tmp = properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption"+Integer.toString(i+1));
			if (tmp != null) {
				tooloptions.add(Integer.toString(i+1) + " - " + properties.getProperty(SECTIONS.dialogtext.toString(), "tooloption"+Integer.toString(i+1)));
			}
		}

	}

	//	@SuppressWarnings({ "deprecation", "static-access" })
	protected void finalize() throws Exception
	{
		logger.removeAllAppenders();
	}

	/*
	 * Unique exception formatting
	 */
	private void format_exception(Exception e)
	{
		StackTraceElement[] st = e.getStackTrace();
		for (StackTraceElement se : st)
		{
			if(se.getClassName().contains(this.getClass().getSimpleName()))
			{
				logger.error(e.getClass().getSimpleName() + " = \"" + e.getMessage() + "\" (triggered by " + se.getClassName() + ":" + se.getLineNumber() + ")");
				break;
			}
		}
	}

	/*
	 * Read properties from external file
	 */
	private	void get_properties() throws Exception
	{
		properties = new XMLProperty();
		String pn = "conf/" + this.getClass().getSimpleName() + ".xml";
		properties.load(pn);
		List<String> lines = Files.readAllLines(Paths.get(pn));
		currentDir = System.getProperty("user.dir");
		debug = Boolean.parseBoolean(properties.getProperty(SECTIONS.general.toString(), "debug"));
		logger.info("Following parameters have been set in ");
		logger.info("==> " + currentDir + "/" + pn + ":");
		logger.info("------------------------------------------------------");
		for(String line : lines) {
			if (line.replaceAll(" ", "").startsWith("<") && !line.replaceAll(" ", "").startsWith("<!")) {
				logger.info(line);
			}
		}
		logger.info("------------------------------------------------------" + System.lineSeparator());
	}

	/*
	 * Check arguments
	 * Read parameters from configuration file
	 */
	private	void get_parameters() throws Exception
	{
		if (System.getProperty("os.name").startsWith("Windows")) {
			windows = true;
		}			

		askforconfirmation = Boolean.parseBoolean(properties.getProperty(SECTIONS.general.toString(), "askforconfirmation"));

		downloadedxml = properties.getProperty(SECTIONS.csvGeneration.toString(), "downloadedxml");
		if (downloadedxml==null || (downloadedxml!=null && downloadedxml.isEmpty())) {
			String info = "Folder for downloaded XML files is not configured - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		} else {
			downloadedxml = correct_folder(downloadedxml);
			add_folder(downloadedxml);
		}
		
		csvfromxml = properties.getProperty(SECTIONS.csvGeneration.toString(), "csvfromxml");
		if (csvfromxml==null || (csvfromxml!=null && csvfromxml.isEmpty())) {
			String info = "Folder for CSV files is not configured - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		} else {
			csvfromxml = correct_folder(csvfromxml);
			add_folder(csvfromxml);
		}
		
		addlevels = Integer.parseInt(properties.getProperty(SECTIONS.csvGeneration.toString(), "addlevels"));
		
		labelregex = properties.getProperty(SECTIONS.csvGeneration.toString(), "labelregex");

		copyxmltoclipboard = Boolean.parseBoolean(properties.getProperty(SECTIONS.csvGeneration.toString(), "copyxmltoclipboard"));

		repidsfordownload = properties.getProperty(SECTIONS.csvGeneration.toString(), "repidsfordownload"); //list of REP IDs for batch processing (physical)
		repmidsfordownload = properties.getProperty(SECTIONS.csvGeneration.toString(), "repmidsfordownload"); //list of REP MIDs for batch processing (logical)
		
		csvreadyforxml = properties.getProperty(SECTIONS.xmlGeneration.toString(), "csvreadyforxml");
		if (csvreadyforxml==null || (csvreadyforxml!=null && csvreadyforxml.isEmpty())) {
			String info = "Folder containing CSV files for conversion to XML is not configured - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		} else {
			csvreadyforxml = correct_folder(csvreadyforxml);
			add_folder(csvreadyforxml);
		}

		xmlreadyforupload = properties.getProperty(SECTIONS.xmlGeneration.toString(), "xmlreadyforupload");
		if (xmlreadyforupload==null || (xmlreadyforupload!=null && xmlreadyforupload.isEmpty())) {
			String info = "Target folder for XML files is not configured - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		} else {
			xmlreadyforupload = correct_folder(xmlreadyforupload);
			add_folder(xmlreadyforupload);
			//create DONE folder
			donefolder = correct_folder(xmlreadyforupload + "DONE");
			add_folder(donefolder);
		}

		srubase = properties.getProperty(SECTIONS.general.toString(), "srubase");
		if (srubase==null || (srubase!=null && srubase.isEmpty())) {
			String info = "Base URL for SRU needs to be configured - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		}

		wsurl = properties.getProperty(SECTIONS.general.toString(), "wsurl");
		if (wsurl==null || (wsurl!=null && wsurl.isEmpty())) {
			String info = "WS URL needs to be configured - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		}

		userid = properties.getProperty(SECTIONS.general.toString(), "userid");
		if (userid==null || (userid!=null && userid.isEmpty())) {
			missinguser = true;
		}

		password = properties.getProperty(SECTIONS.general.toString(), "password");
		if (password==null || (password!=null && password.isEmpty())) {
			missingpassword = true;
		}

		institutioncode = properties.getProperty(SECTIONS.general.toString(), "institutioncode");
		if (institutioncode==null || (institutioncode!=null && institutioncode.isEmpty())) {
			missinginstitution = true;
		}
	}

	private static String correct_folder(String folder) throws Exception
	{
		if (folder.endsWith("\\")||folder.endsWith("/")) {
			folder = folder.substring(0, (folder.length()-1));
		}

		return folder + separator;
	}	

	public static void add_loginfo(String info, boolean newline) throws Exception
	{
		if (windows) {
			if (newline) {
				ToolMenu.showInfo(info, true);
			} else {
				ToolMenu.showInfo(info, false);
			}
		} else {
			if (newline) {
				logger.info(info + System.lineSeparator());
			} else {
				logger.info(info);
			}
		}
	}	

	/*
	 * for testing
	 * transforms XML W3C document to string
	 * */
	public static String getStringFromDocument(Document doc) throws TransformerException {
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		return writer.toString();
	}

	/*
	 * read XML
	 * get content and set variable
	 */
	public static void getContentFromDocument(String responsexml, String tagtoextract) throws Exception
	{
		Document xmlDocument = readXmlFromString(responsexml);
		Element root = xmlDocument.getDocumentElement();
		NodeList nl = root.getChildNodes();

		iepidfromrep=null;
		if (tagtoextract.equalsIgnoreCase("getiepidforrep")) {
			for(int k=0;k<nl.getLength();k++){
				getIePid((Node)nl.item(k));
			}
		}
	}	

	/*
	 * parse SRU response XML snippet
	 * identify IE PID for given REP ID
	 */
	public static void getIePid(Node nodes){
		if(nodes.hasChildNodes()&&iepidfromrep==null) {
			if (nodes.getNodeName().equals("dc:identifier") && nodes.getTextContent().matches("IE[0-9].*")) {
				iepidfromrep = nodes.getTextContent(); //set value of variable
				if (debug) logger.debug("iepidfromrep: "+iepidfromrep);
			}
			NodeList nl=nodes.getChildNodes();
			for(int j=0;j<nl.getLength();j++) {
				getIePid(nl.item(j));
			}
		}
	}

	/* 
	 * read XML from string (get DocumentBuilder object from string)
	 */
	public static Document readXmlFromString(String xml) throws Exception
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xml));
		return builder.parse(is);
	}

	/*
	 *  Check and create directory if needed
	 */
	private void add_folder(String foldername) throws Exception
	{
		File folder = new File(foldername);
		if (!folder.exists())
		{
			String info = "Creating directory " + folder;
			logger.info(info);
			folder.mkdirs();
		}
	}

	/*
	 * create file lines for CSV (physical)
	 */
	private static ArrayList<String> get_csv_line_physical(ArrayList<String> alFileNameId) throws Exception
	{
		/*
		 * new CSV lines are added to string array 'NewCSV'
		 * 'NewCSV' is written to file 'csvname' in 'csvfromxml'
		 */
		ArrayList<String> FileLines = new ArrayList<String>();
		ArrayList<String> repLabels = new ArrayList<String>();
		String replabels = new String();
		String fileline = new String();

		repLabels = SoapRequestClient.repLabels;
		for (String tmp : repLabels) {
			replabels = replabels + tmp + ",";
		}
		
		//create and add file lines
		String filecommas = StringUtils.repeat(",", addlevels);
		String repcommas = StringUtils.repeat(",", repLabels.size());

		fileline = replabels+filecommas+get_label_from_filename(alFileNameId.get(0))+","+alFileNameId.get(1);//only the first line should contain "replabels"
		FileLines.add(fileline);

		for(int j=2;j<alFileNameId.size()-1;j++) {
			fileline = repcommas+filecommas+get_label_from_filename(alFileNameId.get(j))+","+alFileNameId.get(j+1);
			FileLines.add(fileline);
			j = j+1;
		}

		return FileLines;
	}

	/*
	 * Build and write CSV from LOGICAL or PHYSICAL
	 */
	private static void build_and_write_csv(String repmid, ArrayList<String> csvLinesFromXmlFile, String type, ArrayList<String> alFileNameId) throws Exception
	{
		/*
		 * part for file line was generated via ConvertLogicalXmlToCsv.createCsvFromLogicalXML(pathtoxmlfile)
		 * new CSV lines are added to string array 'NewCSV'
		 * 'NewCSV' is written to file 'csvname' in 'csvfromxml'
		 */
		ArrayList<String> NewCSV = new ArrayList<String>();
		NewCSV.clear();
		String headerline = new String();
		String csvname = new String();

		String newline = System.getProperty("line.separator"); // this will take proper line break depending on OS

		//calculate header line - Level 1 to Level n + File ID
		if (type.equalsIgnoreCase("physical")) {
			for (int i=0; i<ConvertLogicalXmlToCsv.depthxml-1+addlevels; i++) {
				headerline = headerline + "Level " + i + ",";
			}
		}
		if (type.equalsIgnoreCase("logical")) {
			for (int i=0; i<ConvertLogicalXmlToCsv.depthxml-1; i++) {
				headerline = headerline + "Level " + i + ",";
			}
		}
		headerline = headerline + "File ID";
		NewCSV.add(headerline);
		
		//add file lines (physical)
		if (type.equalsIgnoreCase("physical") && alFileNameId!=null) {
			ArrayList<String> FileLines = get_csv_line_physical(alFileNameId);
			for(String fileline : FileLines) {
				NewCSV.add(fileline);
			}
		}

		//add file lines (logical)
		if (type.equalsIgnoreCase("logical") && csvLinesFromXmlFile!=null) {
			for(String fileline : csvLinesFromXmlFile) {
				NewCSV.add(fileline);
			}
			csvLinesFromXmlFile.clear();
		}

		csvname = repmid+".csv";
		String inforepmid = String.format("%-15s", repmid);
		FileWriter writecsv;
		try {
			writecsv = new FileWriter(csvfromxml + csvname);
			String info = inforepmid + " - SUCCESS";
		
		add_loginfo(info, true);
		for (int k=0; k<NewCSV.size(); k++)
		{
			if (debug) logger.debug("add line: " + NewCSV.get(k));
			writecsv.write(NewCSV.get(k)+ newline);
		}
		writecsv.close();
		NewCSV.clear();
		NewCSV = null;
		} catch (IOException e) {
			String info = inforepmid + " - ERROR - : " + e.getMessage();
			add_loginfo(info, true);
		}
	}

	/*
	 * extract label from filename via regular expression
	 * if no regex is configured, copy complete filename
	 */
	private static String get_label_from_filename(String filename) throws Exception
	{
		String filelabel = filename;
		try {
			if (labelregex != null) {
				Pattern p = Pattern.compile(labelregex);
				Matcher m = p.matcher(filename);
				while (m.matches()) {
					filelabel = m.group(1);
					if (debug) logger.debug("filelabel: " + filelabel);
					return filelabel;
				}
			}
		} catch (PatternSyntaxException e) {
			e.printStackTrace();
			String info = "Regex pattern syntax exception. Please check <labelregex>" 
					+ labelregex + "</labelregex> in CreateRosettaLogStructMap.xml.";
			add_loginfo(info, true);
		}
		return filelabel;
	}		


	/*
	 * write info into log
	 */
	private static void writing_into(String folder) throws Exception
	{
		String info = "Writing into " + folder;
		add_loginfo(info, true);
	}		


	/*
	 * Start creating structmap xml
	 * search folder that contains adjusted CSV file
	 * read CSV into list if string arrays 'contentcsv'
	 */
	static void create_xml_files(String repidormid, boolean batch) throws Exception
	{
//		String basename = new String();
		File files_dir = new File(csvreadyforxml);
		File[] files = files_dir.listFiles();
		String filename = null;
		String info = null;
//		boolean processing = false;

		if (files==null) { //directory is empty
			info = "There are no CSV files in " + csvreadyforxml + ". Please check!";
			ToolMenu.showInfo("ERROR - " + info, true);
			ToolMenu.f.setCursor(Cursor.getDefaultCursor());
			throw new Exception(info);
		} else {
			if (repidormid!=null) { //single REP processing
				info = "";
				filename = repidormid.toUpperCase()+".csv";
				File file = new File(csvreadyforxml, filename);
				boolean fileexists = file.exists();
				if (fileexists) {
					List<String[]> contentcsv = read_csv_file(file); // read one CSV
					if (debug) {
						info = "Processing CSV '" + csvreadyforxml + filename + "'.";
						add_loginfo(info, true);
					}
					if (!batch) {
						writing_into(xmlreadyforupload);
					}
					write_xml(contentcsv, repidormid, true); // write one XML
				}
				else {
					info = "There is no CSV file for " + repidormid + " in " + csvreadyforxml + ". Please check!";
					ToolMenu.showInfo("ERROR - " + info, true);
					throw new Exception(info);
				}
			} else { //batch processing
				filename = null;
				writing_into(xmlreadyforupload);
				for( File file : files ) {
					filename = file.getName();
					if (filename.matches("REP.*\\.csv")) {
						repidormid = filename.substring(0, filename.lastIndexOf("."));
						create_xml_files(repidormid, true);
					}
				}
			}
		}

//		if (files!=null) { 
//			String info = "Writing into " + xmlreadyforupload;
//			add_loginfo(info, true);
//
//			for( File file : files ) {
//				String filename = file.getName();
//				if (repid!=null && filename.toUpperCase().matches(".*\\.CSV")) { //process only one CSV
//					basename = filename.substring(0, filename.lastIndexOf("."));
//					if (filename.equalsIgnoreCase(repid+".csv")) {
//						List<String[]> contentcsv = read_csv_file(file); // read one CSV
//						if (debug) {
//							info = "Processing CSV '" + csvreadyforxml + filename + "'.";
//							add_loginfo(info, true);
//						}
//						write_xml(contentcsv, basename, true); // write one XML
//						processing = true;
//					} else continue;
//				}
//				if (filename.toUpperCase().matches("REP.*\\.CSV") && repid==null) { //process all CSV
//					basename = filename.substring(0, filename.lastIndexOf("."));
//					List<String[]> contentcsv = read_csv_file(file); // read one CSV
//					if (debug) {
//						info = "Processing CSV '" + csvreadyforxml + filename + "'.";
//						add_loginfo(info, true);
//					}
//					write_xml(contentcsv, basename, false); // write multiple XML -> batch processing, i.e. no copy of XML into cache
//					processing = true;
//				}
//			}
//			if (!processing) {
//				info = "There is no CSV file for " + repid + " in " + csvreadyforxml + ". Please check!";
//				add_loginfo("ERROR - " + info, true);
//				ToolMenu.f.setCursor(Cursor.getDefaultCursor());
//				throw new Exception(info);
//			}
//		} else {
//			String info = "There are no CSV files in " + csvreadyforxml + ". Please check!";
//			add_loginfo("ERROR - " + info, true);
//			ToolMenu.f.setCursor(Cursor.getDefaultCursor());
//			throw new Exception(info);
//		}
	}

	/*
	 * read in the CSV and transform to array
	 */
	private static List<String[]> read_csv_file(File file) throws Exception
	{
		List<String[]> contentcsv = new ArrayList<>();		
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line;
		reader.readLine();//ignore first line (header line)
		while ((line = reader.readLine()) != null) {
			//handle comma in quotes: replace by '\u0333'
			StringBuilder builder = new StringBuilder(line);
			boolean inquotes = false;
			for (int currentIndex = 0; currentIndex < builder.length(); currentIndex++) {
			    char currentChar = builder.charAt(currentIndex);
			    if (currentChar == '\"') inquotes = !inquotes; // toggle state
			    if (currentChar == ',' && inquotes) {
			        builder.setCharAt(currentIndex, '\u0333');  // replace this character (combining double low line) back to comma ',' in write_xml()
			    }
			}
			line = builder.toString();
			line = line.replaceAll("^\"", ""); // remove quote from start
			line = line.replaceAll("\",", ","); // remove quote before comma
			line = line.replaceAll(",\"", ","); // remove quote after comma
			line = line.replaceAll("\"$", ""); // remove quote from end
			contentcsv.add(line.split(","));
		}
		reader.close();
		return contentcsv;
	}


	private static void write_xml(List<String[]> contentcsv, String basename, boolean singlexml) throws Exception
	{
		String newline = System.getProperty("line.separator"); // this will take proper line break depending on OS
		String xmlname = basename + ".xml"; //basename equals the REP (M)ID
		ArrayList<String> NewXML = new ArrayList<String>();
		String closediv = "</mets:div>";
		String closestructmap = "</mets:structMap>";

		String info = String.format("%-15s", basename) + " - SUCCESS";
		boolean donefileexists = new File(donefolder, xmlname).exists();
		if (donefileexists) {
			info = info + " (NOTE: Update done before.)";
		}

		add_loginfo(info, true);
		FileWriter writexml = new FileWriter(xmlreadyforupload + xmlname);

		//initiate current DIVs matrix: no DIVs are open
		String[] CurrentFileDivMatrix = new String[contentcsv.get(0).length];
		for(int l=0;l<CurrentFileDivMatrix.length;l++) {
			CurrentFileDivMatrix[l] = "no";
		}

		String structmapline = "<mets:structMap xmlns:mets=\"http://www.loc.gov/METS/\" ID=\""+basename+"\" TYPE=\"LOGICAL\">";
		NewXML.add(structmapline);
		for(int j=0;j<contentcsv.size();j++) { //process complete CSV
			
			String[] csvline = contentcsv.get(j);
			
			String[] filelinematrix = new String[contentcsv.get(0).length-2];
			for (int n=0; n<csvline.length-2; n++) {//iterate through all columns except of last (i.e. 'File ID')
				if (csvline[n].isEmpty()) {
					filelinematrix[n] = "no"; // nothing to do
				} else filelinematrix[n] = "yes"; // DIV is opened on this level
			}

			/*
			 * compare filelinematrix with CurrentFileDivMatrix:
			 * if DIV in line is opened, check if there are any open DIVs on same or lower level, and close them
			 */
			String filetag = "";//file
			String completeline = "";//complete line
			int filedivs = filelinematrix.length;
			for (int n=0; n<filedivs; n++) {
				if (filelinematrix[n]=="yes") {
					completeline = completeline + write_metsdiv(csvline[n], n); // write <mets:div LABEL="{csvline[n]}">
					for (int p=n; p<filedivs; p++) {//check against current and following (i.e. lower) levels
						if (debug) {
							logger.debug("line "+(j-1)+" -- "+"filelinematrix-n["+n+"]: "+filelinematrix[n]+" -- "+"CurrentFileDivMatrix-p["+p+"]: "+CurrentFileDivMatrix[p]);
						}
						if (CurrentFileDivMatrix[p]=="yes") {
							completeline = closediv + completeline; //close this level
							CurrentFileDivMatrix[p] = "no"; //indicate that this level was closed
						}
					}
					CurrentFileDivMatrix[n] = "yes";
				}
			}

			if (!csvline[csvline.length-2].isEmpty()) {//file label exists
				String csvcell = csvline[csvline.length-2];
				filetag = "<mets:div LABEL=\"" + csvcell + "\" TYPE=\"FILE" + "\">" 
						+ "<mets:fptr FILEID=\"" + csvline[csvline.length-1] + "\"/>" + closediv;
			} else {
				/*
				 * special case: file label is also used as structmap label (e.g. 'Frontespizio')
				 * find last label and transform it to file label
				 */
				for (int n=csvline.length-2; n>0; n--) {
					if (!csvline[n].isEmpty()) {
						filetag = "<mets:fptr FILEID=\"" + csvline[csvline.length-1] + "\"/>" + closediv;
						completeline = completeline.replaceFirst(">$", " TYPE=\"FILE\""+">");
						CurrentFileDivMatrix[n] = "no";
						break;
					}
				}

			}
			NewXML.add(completeline + filetag);
		}
		
		/*
		 * close all open DIVs
		 */
		String closingdivs="";
		for (int r=0; r<CurrentFileDivMatrix.length; r++) {//check for open DIVs
			if (CurrentFileDivMatrix[r]=="yes") {
				closingdivs = closingdivs + closediv; //close this level
			}
		}
		NewXML.add(closingdivs);
		NewXML.add(closestructmap);//close structure map

		for (int k=0; k<NewXML.size()-1; k++)//write XML (except last line)
		{
			writexml.write(NewXML.get(k).replaceAll("\u0333", ",")+ newline); //put comma back
		}
		writexml.write(NewXML.get(NewXML.size()-1));//write last line
		writexml.close();
		contentcsv.clear();

		//copy to clipboard
		if (singlexml && copyxmltoclipboard && !NewXML.isEmpty()) {
			String structmapxml = NewXML.toString();
			structmapxml = structmapxml.substring(1, structmapxml.length()-1).replaceAll(">, <", "><");
			StringSelection stringSelection = new StringSelection(structmapxml);
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(stringSelection, null);
		}
	}

	private static String write_metsdiv(String csvcell, int n) throws Exception
	{
		if (!csvcell.isEmpty()) {
			if (csvcell.matches("^\".*\"$")) { //content is in hyphens "..."
				csvcell = csvcell.replaceAll("^\"", "");
				csvcell = csvcell.replaceAll("\"$", "");
			}
			if (debug) {
				String metsdivopenerstart = "<mets:div X"+n+"LABEL=\"";
				String metsdivopenerend = "\">";
				String metsdivdebug = metsdivopenerstart+csvcell+metsdivopenerend;
				logger.debug("metsdiv with level: "+metsdivdebug);
			}
			String metsdivopenerstart = "<mets:div LABEL=\"";
			String metsdivopenerend = "\">";
			String metsdiv = metsdivopenerstart+csvcell+metsdivopenerend;
			return metsdiv;
		} else return csvcell;
	}


	/*
	 * Start update of REPs
	 * search folder that contains created structure map XML files
	 * read XML, call update via soap, check result
	 * if success, move XML file to donefolder
	 */
	static void update_repository_object(String repidormid) throws Exception
	{
		String updateresult = new String();
		File files_dir = new File(xmlreadyforupload);
		File[] files = files_dir.listFiles();
		String filename = null;

		if (files==null || files.length<=1) { //directory is empty (there is only DONE folder)
			String info = "There are no XML files in " + xmlreadyforupload + ". Please check!";
			ToolMenu.showInfo("ERROR - " + info, true);
			ToolMenu.f.setCursor(Cursor.getDefaultCursor());
			throw new Exception(info);
		} else {
			if (repidormid!=null) { //single REP processing
				String info = "";
				String inforepidormid = String.format("%-15s", repidormid);
				filename = repidormid.toUpperCase()+".xml";
				boolean fileexists = new File(xmlreadyforupload, filename).exists();
				if (fileexists) {
					String structmapxml = Files.lines(Paths.get(xmlreadyforupload, filename)).collect(Collectors.joining("\n"));
					updateresult = SoapRequestClient.addMdViaSoap(wsurl, userid, 
							password, institutioncode, repidormid, structmapxml, "true", "mets_section", "structMap"); // update REP

					if (debug) {
						logger.info("updateresult: " + updateresult);
					}
					String updateerror = check_result_of_update(updateresult);
					if (debug) {
						logger.info("updateerror: " + updateerror);
					}
					if (updateerror != null) {
						info = inforepidormid + " - ERROR (" + updateerror + ")";
						add_loginfo(info, true);
					} else {
						info = inforepidormid + " - SUCCESS";
						Path fileToMovePath = Paths.get(xmlreadyforupload, filename);
						Path targetPath = Paths.get(donefolder, filename);
						try {
							boolean donefileexists = new File(donefolder, filename).exists();
							if (donefileexists) {
								info = info + " (NOTE: Update done before.)";
								Files.deleteIfExists(targetPath);
							}
							add_loginfo(info, true);
							renameFile(fileToMovePath, targetPath); //move file to avoid double processing
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				else {
					info = "There is no XML file for " + repidormid + " in " + xmlreadyforupload + ". Please check!";
					ToolMenu.showInfo("ERROR - " + info, true);
					ToolMenu.f.setCursor(Cursor.getDefaultCursor());
					throw new Exception(info);
				}
			} else { //batch processing
				filename = null;
				for( File file : files ) {
					filename = file.getName();
					if (filename.matches("REP.*\\.xml")) {
						repidormid = filename.substring(0, filename.lastIndexOf("."));
						update_repository_object(repidormid);
					}
				}
			}
		}
	}

	private static String check_result_of_update(String updateresult) throws Exception
	{
		//...<soap:Body><ns2:updateMDResponse xmlns:ns2="http://dps.exlibris.com/"/></soap:Body>... indicates successful update
		if (updateresult.contains("updateMDResponse")) {
			updateresult = null;
			return updateresult;
		}
		if (updateresult.contains("<faultstring>")) {
			updateresult = updateresult.substring(updateresult.indexOf("<faultstring>")+13, updateresult.indexOf("</faultstring>"));
			return updateresult;
		}
		return updateresult;
	}

	private static void renameFile(Path fileToMovePath, Path targetPath) throws IOException 
	{
		Files.move(fileToMovePath, targetPath); //rename file to avoid double processing
	}

	private static void tmpout(String name, String value) throws IOException 
	{
		System.out.println(name+": "+value);
	}

	private static void writeFile(String folder, String filename, String content) throws Exception, IOException 
	{
		FileWriter writexml = new FileWriter(folder + filename);
		
		writexml.append(content);
		writexml.close();
	}

	/*
	 * 
	 */
	static void create_csv_from_logical_structmap(String repmid) throws Exception, IOException
	{
		boolean errorexists = false;
		String inforepmid = String.format("%-15s", repmid);
		String msg = "";
		String info = "";
		//check if ID is REP MID - REP{number}-{number}
		if (!repmid.matches("^REP[0-9]*-[0-9]*$")) {
			msg = "MID is not valid";
			info = inforepmid + " - ERROR (" + msg + ")";
			add_loginfo(info, true);
			errorexists = true;
		}
		else {
			//request logical structure map via soap
			String soapresponse = null;
			try {
				if (!errorexists) {
					soapresponse = SoapRequestClient.getLogicalStructmapViaSoap(wsurl, userid, password, institutioncode, repmid);
				}
			} catch (IOException e) {
				info = "ERROR - " + e.getMessage();
				add_loginfo(info, true);
			}
			if (soapresponse != null && !soapresponse.contains("<faultstring>")) {
				if (debug) logger.debug("soapresponse: "+soapresponse);
				try {
					//write response to xml into folder <downloadedxml>
					writeFile(downloadedxml, repmid + ".xml", soapresponse);
				} catch (Exception e) {
					if (debug) {
						info = "ERROR - " + e.getMessage();
						add_loginfo(info, true);
					}
					msg = "No connection. Please check configuration (including user and password) - tool stopped processing";
					info = inforepmid + " - ERROR (" + msg + ")";
					add_loginfo(info, true);
					throw new Exception(info);
				}
			} else {
				if (soapresponse.contains("<faultstring>")) {
					msg = soapresponse.substring(soapresponse.indexOf("<faultstring>")+13, soapresponse.indexOf("</faultstring>"));
					info = inforepmid + " - ERROR (" + msg + ")";
					add_loginfo(info, true);
					errorexists = true;
				} else {
					msg = "Data could not be received - tool stopped processing";
					info = inforepmid + " - ERROR (" + msg + ")";
					add_loginfo(info, true);
					throw new Exception(info);
				}
			}
			//convert XML to CSV
			if (!errorexists) {
				convert_xml_to_csv(repmid, "logical");
			}
		}
	}

	public static void create_csv_from_physical_structmap(String repid) throws Exception, IOException
	{
		String sruurl;
		String sruoperation = "operation=searchRetrieve&startRecord=1";
		String sruquery = "&query=REP.internalIdentifier.internalIdentifierType.PID=";
		sruurl = srubase+sruoperation+sruquery;
		if (debug) logger.debug("sruurl: "+sruurl);
		if (debug) logger.debug("repid: "+repid);

		String sruresponse = SoapRequestClient.getSruResponse(sruurl, repid);
		if (debug) logger.debug("sruresponse: "+sruresponse);
		if (sruresponse!=null && sruresponse.contains("<numberOfRecords>1</numberOfRecords>")) {
			getContentFromDocument(sruresponse,"getiepidforrep");
		} else {
			String info = "Data for " + repid + " could not be found - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		}

		String soapresponse = null;
		try {
			soapresponse = SoapRequestClient.getIeXmlViaSoap(wsurl, userid, password, institutioncode, iepidfromrep);
		} catch (IOException e) {
			String info = "ERROR - " + e.getMessage();
			add_loginfo(info, true);
		}
		if (soapresponse != null && !soapresponse.contains("<faultstring>")) {
			if (debug) logger.debug("soapresponse: "+soapresponse);
			try {
				String tmp = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><mets:mets xmlns:mets=\"http://www.loc.gov/METS/\">"; 
				String check = "<mets:structMap ID=\""+repid+"-1\" TYPE=\"PHYSICAL\">";	
				int mapstart = soapresponse.indexOf(check);
				int mapend = soapresponse.indexOf("</mets:structMap>");
				tmp = tmp + soapresponse.substring(mapstart, mapend-1)
					+ "</mets:structMap></mets:mets>";
				//write response to xml into folder <downloadedxml>
				writeFile(downloadedxml, repid + ".xml", tmp);
			} catch (Exception e) {
				if (debug) {
					String info = "ERROR - " + e.getMessage();
					add_loginfo(info, true);
				}
				String info = "ERROR - Couldn't get structure map XML for " + repid + " - tool stopped processing" + "\n" 
							+ "ERROR - Please check connection configuration (including user and password).";
				add_loginfo(info, true);
				throw new Exception("- Couldn't get structure map XML for " + repid + " - tool stopped processing");
			}
			//convert XML to CSV
			convert_xml_to_csv(repid, "physical");
		} else {
			String info = "Data for " + repid + " could not be received - tool stopped processing";
			add_loginfo("ERROR - " + info, true);
			throw new Exception(info);
		}
	}


	/*
	 * convert downloaded XML in folder <downloadedxml> to CSV
	 */
	private static void convert_xml_to_csv(String repid, String type) throws Exception
	{
		System.out.println("convert_xml_to_csv "+repid);
		//convert XML to CSV
		ArrayList<String> alFilenameId = new ArrayList<String>(); //single string with iteration of file id and name
		ArrayList<String> csvLineFromXmlFile = new ArrayList<String>();
		String pathtoxmlfile = downloadedxml + repid + ".xml";	
		if (type.equalsIgnoreCase("logical")) {
			ConvertLogicalXmlToCsv.depthxml = 0;	
			csvLineFromXmlFile = ConvertLogicalXmlToCsv.convertLogicalXmlToCsv(pathtoxmlfile,type);
			if (csvLineFromXmlFile != null) {
				build_and_write_csv(repid, csvLineFromXmlFile, type, null);
				csvLineFromXmlFile = null;
			}
		}
		if (type.equalsIgnoreCase("physical")) {
			ConvertLogicalXmlToCsv.depthxml = 0;	
			try {
					NodeList childNodes = ConvertLogicalXmlToCsv.getNodeList(pathtoxmlfile, type).item(0).getChildNodes();
					boolean gotdepthxml = ConvertLogicalXmlToCsv.getMaxDepthXML(childNodes, 0);//get hierarchy level
					if (gotdepthxml) {
						alFilenameId = SoapRequestClient.getFileNameIdFromPhysicalStructMap(pathtoxmlfile, repid);
					}
				} catch (Exception e) {
					String info = "ERROR - " + e.getMessage();
					add_loginfo(info, true);
					ToolMenu.f.setCursor(Cursor.getDefaultCursor());
					throw new Exception("ERROR - " + "Data for " + repid + " could not be received - tool stopped processing");
				}
				System.out.println("pathtoxmlfile (physical): "+pathtoxmlfile);
				System.out.println("depthxml (physical): "+ConvertLogicalXmlToCsv.depthxml);
			build_and_write_csv(repid, null, type, alFilenameId);
		}
	}
	
	
	/*
	 * check files in <downloadedxml> and initiate convert_xml_to_csv()
	 */
	static void run_convert_xml_to_csv(String downloadedxml) throws Exception
	{
		ArrayList<String> fileList = list_files(downloadedxml);//list of files prefixed by type
		String repid = "";
		String type = "";
		String info = "Writing into " + csvfromxml;
		add_loginfo(info, true);
		
		for (String file : fileList) {
			repid = file.substring(file.indexOf("_")+1,file.indexOf(".xml"));
			type = file.substring(0,file.indexOf("_"));
			convert_xml_to_csv(repid, type);
		}
	}
	
	
	private static ArrayList<String> list_files(String downloadedxml) throws IOException {
		ArrayList<String> fileList = new ArrayList<>();
		try (DirectoryStream<Path> directory = Files.newDirectoryStream(Paths.get(downloadedxml))) {
			for (Path file : directory) {
				if (!Files.isDirectory(file)) {
					String filename = file.getFileName().toString();
					if (filename.matches("^REP[0-9].*\\.xml$")) {
						if (filename.matches("^REP[0-9]*-[0-9]*\\.xml$")) {
							filename = "logical_" + filename;
						}
						if (filename.matches("^REP[0-9]*\\.xml$")) {
							filename = "physical_" + filename;
						}
						fileList.add(filename);
					} else continue;
				}
			}
		}
		return fileList;
	}
	
	/*
	 * read file with REP IDs (one per line)
	 * start creation of CSV files
	 */
	static void bulkcreate_csv(String repidsfile, boolean fromphysical) throws Exception
	{
		try {
			if (repidsfile != null) {
				BufferedReader reader = new BufferedReader(new FileReader(repidsfile));
				String line;
				String info = "Writing into " + csvfromxml;
				add_loginfo(info, true);
				while ((line = reader.readLine()) != null) {
					if (fromphysical) {
						create_csv_from_physical_structmap(line);
					} else {
						create_csv_from_logical_structmap(line);
					}
				}
				reader.close();
			} else {
				String info = "ERROR - File " + repidsfile + " could not be found - tool stopped processing";
				add_loginfo(info, true);
				ToolMenu.f.setCursor(Cursor.getDefaultCursor());
				throw new Exception(info);
			}
		} catch (Exception e) {
			String info = "ERROR - " + e.getMessage();
			add_loginfo(info, true);
		}
	}
	
	
	public static void main(String[] args) {

		org.apache.log4j.helpers.LogLog.setQuietMode(true);
		CreateRosettaLogStructMap myself = null;
		try {
			myself = new CreateRosettaLogStructMap();
			myself.get_parameters();
			if (windows) {
				try {
					new ToolMenu();
				} catch (Throwable e) {
						logger.error("ERROR: " + e.getLocalizedMessage());
				}
			} //else {
				//start_unix_dialog();
			//}
		} catch (Exception e) {
			if (myself != null) {
				myself.format_exception(e);
				if (windows) {
					logger.error("ERROR: The log window (JFrame) couldn't be started. Please check the configuration, e.g. that all mandatory elements exist");
					logger.error("ERROR: " + e.getLocalizedMessage());
					if (ToolMenu.getFrames()!=null) ToolMenu.showInfo("ERROR: " + e.getLocalizedMessage(), true);
				}
			}
			else {
				logger.error(e.getLocalizedMessage()); 
				if (windows) {
					logger.error("ERROR: The log window (JFrame) couldn't be started. Please check the configuration, e.g. that all mandatory elements exist");
					logger.error("ERROR: " + e.getLocalizedMessage());
					if (ToolMenu.getFrames()!=null) ToolMenu.showInfo("ERROR: " + e.getLocalizedMessage(), true);
				}
			}
		}
	}
}

